package TOURISM;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.ResultSet;
import java.sql.SQLException;

public class Home extends JFrame{
    String username;
    int cost=0;
    public static void main(String[] args)
    {
        new Home("").setVisible(true);
    }

    public Home(String username) {
        super("Travel and Tourism Management System");
        this.username = username;
        setForeground(Color.CYAN);
        setLayout(null);

        JLabel l1 = new JLabel("RS Tours and Travels");
        l1.setForeground(new Color(80, 32, 32));
        l1.setFont(new Font("STENCIL", 0, 65));
        l1.setBounds(280, 140, 1100, 100);
        add(l1);

        JButton m1 = new JButton(" CUSTOMER");
        m1.setForeground(new Color(19, 19, 13));
        //m1.setIcon(new ImageIcon(getClass().getResource("/icons/customer11.jpg")));
        m1.setFont(new Font("Candara ", 1, 20));
        m1.setBounds(50,50,170,50);
        m1.setForeground(new Color(19, 14, 14));
        m1.setBackground(new Color(30, 213, 218));
        m1.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent ae){
                try{
                    new UpdateCustomer(username).setVisible(true);
                }catch(Exception e ){}
            }
        });
        add(m1);

        JButton m2 = new JButton(" PACKAGES  ");
        //m2.setIcon(new ImageIcon(getClass().getResource("/icons/package.jpg")));
        //m2.setBorder(BorderFactory.createLineBorder(new Color(80, 32, 32)));
        m2.setFont(new Font("Candara ", 1, 20));
        m2.setBounds(230,50,170,50);
        m2.setForeground(new Color(19, 14, 14));
        m2.setBackground(new Color(250, 245, 2));
        m2.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                try{
                    new CheckPackage(username).setVisible(true);
                }catch(Exception e ){}
            }
        });
        add(m2);

        JButton m3 = new JButton("HOTELS");
        //m3.setBorder(BorderFactory.createLineBorder(new Color(80, 32, 32)));
        //m3.setIcon(new ImageIcon(getClass().getResource("/icons/hotelnew.jpg")));
        //m3.setForeground(new Color(80, 32, 32));
        m3.setFont(new Font("Candara ", 1, 20));
        m3.setBounds(410,50,170,50);
        m3.setForeground(new Color(19, 14, 14));
        m3.setBackground(new Color(30, 213, 218));
        m3.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                new BookHotel(username).setVisible(true);
            }
        });
        add(m3);

        JButton m5 = new JButton("PAYMENT ");
        //m5.setForeground(new Color(80, 32, 32));
        //m5.setIcon(new ImageIcon(getClass().getResource("/icons/dollar.jpg")));
        //m5.setBorder(BorderFactory.createLineBorder(new Color(80, 32, 32)));
        m5.setFont(new Font("Candara ", 1, 20));
        m5.setBounds(590,50,170,50);
        m5.setForeground(new Color(19, 14, 14));
        m5.setBackground(new Color(250, 245, 2));
        m5.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae)
            {
                Conn c = new Conn();
                try
                {
                    int price = 0;
                    int pricee=0;
                    //ResultSet rs = c.s.executeQuery("select * from customer where name='" + c1.getSelectedItem() + "'");
                    ResultSet rs = c.s.executeQuery("select * from bookpackage where username='" + username + "'");
                    if (rs.next()) {
                        price = Integer.parseInt(rs.getString("cost"));
                    }
                    cost += price;
                    rs = c.s.executeQuery("select * from bookhotel where username='" + username + "'");
                    if (rs.next()) {
                        price = Integer.parseInt(rs.getString("price"));
                    }
                    cost += price;
                    //rs.close();
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                new Payment(String.valueOf(cost)).setVisible(true);
                cost=0;
            }
        });
        add(m5);

        JButton m6 = new JButton(" UTILITY  ");
        //m6.setBorder(BorderFactory.createLineBorder(new Color(80, 32, 32)));
        //m6.setIcon(new ImageIcon(getClass().getResource("/icons/utility.jpg")));
        //m6.setForeground(new Color(80, 32, 32));
        m6.setFont(new Font("Candara ", 1, 20));
        m6.setBounds(770,50,150,50);
        m6.setForeground(new Color(19, 14, 14));
        m6.setBackground(new Color(30, 213, 218));
        m6.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent ae){
                try{
                    Runtime.getRuntime().exec("calc.exe");
                }catch(Exception e){ }
            }
        });
        add(m6);

        JButton m7 = new JButton(" ABOUT  ");
        //m7.setBorder(BorderFactory.createLineBorder(new Color(80, 32, 32)));
        //m7.setIcon(new ImageIcon(getClass().getResource("/icons/question.jpg")));
        //m7.setForeground(new Color(80, 32, 32));
        m7.setFont(new Font("Candara ", 1, 20));
        m7.setBounds(930,50,150,50);
        m7.setForeground(new Color(19, 14, 14));
        m7.setBackground(new Color(250, 245, 2));
        m7.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent ae)
            {
                new About().setVisible(true);
            }
        });
        add(m7);

        JButton m8 = new JButton(" LOGOUT  ");
        //m8.setBorder(BorderFactory.createLineBorder(new Color(80, 32, 32)));
        //m8.setIcon(new ImageIcon(getClass().getResource("/icons/logout.jpg")));
        //m8.setFont(new Font("Candara", 1, 22));
        //m8.setForeground(new Color(80, 32, 32));
        m8.setFont(new Font("Candara ", 1, 20));
        m8.setBounds(1090,50,150,50);
        m8.setForeground(new Color(19, 14, 14));
        m8.setBackground(new Color(30, 213, 218));
        m8.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent ae)
            {
                setVisible(false);
                new Login().setVisible(true);
            }
        });
        add(m8);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/home.jpg"));
        Image i2 = i1.getImage().getScaledInstance(1281, 640,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel NewLabel = new JLabel(i3);
        NewLabel.setBounds(0, 0, 1281, 680);
        add(NewLabel);

        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setVisible(true);
        getContentPane().setBackground(Color.WHITE);
    }
}
