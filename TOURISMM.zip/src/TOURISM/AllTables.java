package TOURISM;

import java.sql.SQLException;
import java.util.Scanner;

public class AllTables
{
    public static void main(String ...s) throws SQLException {
        Conn c=new Conn();
        Scanner s222=new Scanner(System.in);
        System.out.println("Enter your choice:");
        System.out.println("1.Create table");
        System.out.println("2.Delete tables");
        int ch=s222.nextInt();
        switch(ch)
        {
            case 1:
                c.s.execute("create table account(username varchar(25) NOT NULL PRIMARY KEY,name varchar(25), password varchar(200), question varchar(45),answer varchar(25),Payment_Status varchar(30),Date date default null)");
                c.s.execute("create table bookhotel(username varchar(25),name varchar(30), persons varchar(10), days varchar(10),ac varchar(10),food varchar(10),id varchar(20), number varchar(20), phone varchar(20),price varchar(20),booked date default null)");
                c.s.execute("create table bookpackage(username varchar(25) NOT NULL PRIMARY KEY, selected varchar(20), person int, id_type varchar(25), number varchar(30), phone varchar(30), cost varchar(20), currentp varchar(25),booked date default null)");
                c.s.execute("create table customer (username varchar(25),id_type varchar(25), number varchar(30), name varchar(25),gender varchar(10), country varchar(25),address varchar(50), phone varchar(15), email varchar(45))");
                c.s.execute("create table hotel(name varchar(30), costperperson varchar(20), acroom varchar(10), foodincluded varchar(10),place varchar(30),HotelCode varchar(30) NOT NULL PRIMARY KEY)");
                c.s.execute("create table adminaccount(adminname varchar(20) NOT NULL PRIMARY KEY, password varchar(20))");
                c.s.execute("create table createpackage(place varchar(30) NOT NULL PRIMARY KEY, block01 varchar(50),block02 varchar(50),block03 varchar(50),block04 varchar(50),block05 varchar(50),block06 varchar(50),block07 varchar(50), block08 varchar(50), price varchar(15))");
                c.s.execute("create table createpackage(place varchar(30) NOT NULL PRIMARY KEY,block varchar(650), price varchar(15) NOT NULL)");
                c.s.execute("create table locations(currentplace varchar(30) NOT NULL PRIMARY KEY,address varchar(100),cityortown varchar(40),area varchar(40),pincode varchar(20),phone varchar(18))");
                c.s.execute("create table transport(distance varchar(50) NOT NULL PRIMARY KEY,price varchar(30))");
                c.s.execute("create table adminrecords(AdminName varchar(50) NOT NULL ,in_time varchar(30),out_time varchar(30),Date date default null)");
                break;
            case 2:
                c.s.executeUpdate("drop table account");
                c.s.executeUpdate("drop table bookhotel");
                c.s.executeUpdate("drop table bookpackage");
                c.s.executeUpdate("drop table customer");
                c.s.executeUpdate("drop table hotel");
                c.s.executeUpdate("drop table adminaccount");
                c.s.executeUpdate("drop table createpackage");
                c.s.executeUpdate("drop table locations");
                c.s.executeUpdate("drop table transport");
                c.s.executeUpdate("drop table adminrecords");
                break;
        }


    }

}
