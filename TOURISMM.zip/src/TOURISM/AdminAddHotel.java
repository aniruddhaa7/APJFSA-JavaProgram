package TOURISM;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AdminAddHotel extends JFrame
{
    public static void main(String[] args)
    {
        new AdminAddHotel().setVisible(true);
    }
    Conn c;
    ResultSet rs;
    AdminAddHotel()
    {
        setBounds(270, 120, 750, 450);

        JPanel p1 = new JPanel();
        setContentPane(p1);
        p1.setBackground(Color.WHITE);
        p1.setLayout(null);

        JLabel L1 = new JLabel("ADD HOTEL");
        L1.setFont(new Font("Yu Mincho", Font.PLAIN, 25));
        L1.setBounds(290, 20, 200, 25);
        add(L1);

        JLabel l0 = new JLabel("HOTEL CODE: ");
        l0.setFont(new Font("Yu Mincho", Font.PLAIN, 15));
        l0.setBounds(120, 60, 150, 25);
        add(l0);

        JTextField l12 = new JTextField();
        l12.setBounds(270, 60, 220, 25);
        add(l12);

        JLabel l2 = new JLabel("PLACE/CITY NAME: ");
        l2.setFont(new Font("Yu Mincho", Font.PLAIN, 15));
        l2.setBounds(120, 100, 150, 25);
        add(l2);

        Choice c1=new Choice();
        c=new Conn();
        try
        {
            ResultSet rs = c.s.executeQuery("select * from locations");
            while (rs.next())
            {
                if(rs.getString(1).equals("NONE"))
                {
                    continue;
                }
                else
                {
                    c1.add(rs.getString(1));
                }
            }
            rs.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        c1.setBounds(270,100,220,60);
        add(c1);

        JLabel l4 = new JLabel("HOTEL NAME: ");
        l4.setFont(new Font("Yu Mincho", Font.PLAIN, 15));
        l4.setBounds(120, 140, 150, 25);
        add(l4);

        JTextField l6 = new JTextField();
        l6.setBounds(250, 140, 370, 25);
        p1.add(l6);

        JLabel l5 = new JLabel("COST PER PERSON: ");
        l5.setFont(new Font("Yu Mincho", Font.PLAIN, 15));
        l5.setBounds(120, 180, 170, 25);
        add(l5);

        JTextField l7 = new JTextField();
        l7.setBounds(280, 180, 340, 25);
        p1.add(l7);

        JLabel l10 = new JLabel("AC ROOM CHARGE: ");
        l10.setFont(new Font("Yu Mincho", Font.PLAIN, 15));
        l10.setBounds(120, 220, 170, 25);
        add(l10);

        JTextField l8 = new JTextField();
        l8.setBounds(280, 220, 340, 25);
        p1.add(l8);

        JLabel l11 = new JLabel("FOOD CHARGE: ");
        l11.setFont(new Font("Yu Mincho", Font.PLAIN, 15));
        l11.setBounds(120, 260, 170, 25);
        add(l11);

        JTextField l9 = new JTextField();
        l9.setBounds(250, 260, 370, 25);
        p1.add(l9);

        JButton l14=new JButton("CLICK TO ADD");
        l14.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                try
                {
                    c = new Conn();
                    rs=c.s.executeQuery("select * from hotel");
                    while(rs.next())
                    {
                        if(l6.getText().isEmpty()||l7.getText().isEmpty()||l8.getText().isEmpty()||l9.getText().isEmpty()||l12.getText().isEmpty())
                        {
                            JOptionPane.showMessageDialog(null,"SOME ENTRIES ARE MISSING");
                            return;
                        }
                        if(l12.getText().equals(rs.getString(6)))
                        {
                            JOptionPane.showMessageDialog(null, "Same code registered Choose Another");
                            return;
                        }
                        while (rs.next()) {
                            String comp = l6.getText();
                            if (comp.equals(rs.getString(1))) {
                                c.s.executeUpdate("delete from hotel where name='" + rs.getString(1) + "'");
                            }
                        }
                        String query = "insert into hotel values('" + l6.getText() +"-"+c1.getSelectedItem()+ "','" + l7.getText() + "','" + l8.getText() + "','" + l9.getText() + "','" + c1.getSelectedItem() + "','" + l12.getText() + "')";
                        c.s.executeUpdate(query);
                        JOptionPane.showMessageDialog(null, "Hotel Added Successfully");
                        setVisible(false);
                        new AdminAddHotel().setVisible(true);
                        break;
                    }
                }
                catch (SQLException ex){}
            }
        });
        l14.setBounds(170, 300, 160, 25);
        l14.setBackground(Color.BLACK);
        l14.setForeground(Color.ORANGE);
        p1.add(l14);

        JButton back=new JButton("Back");
        back.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });
        back.setBounds(420, 300, 100, 25);
        back.setBackground(Color.BLACK);
        back.setForeground(Color.ORANGE);
        add(back);

        JButton l15=new JButton("EDIT");
        l15.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                Conn c = new Conn();
                setVisible(false);
                new AdminUpdateHotel().setVisible(true);
                //rs.close();
            }
        });
        l15.setBounds(170, 340, 100, 25);
        l15.setBackground(Color.BLACK);
        l15.setForeground(Color.ORANGE);
        p1.add(l15);

        JButton l16=new JButton("DELETE");
        l16.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                Conn c = new Conn();
                setVisible(false);
                new AdminDeleteHotel().setVisible(true);
                //rs.close();
            }
        });
        l16.setBounds(420, 340, 100, 25);
        l16.setBackground(Color.BLACK);
        l16.setForeground(Color.ORANGE);
        p1.add(l16);
    }
}
