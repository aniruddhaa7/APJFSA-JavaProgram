package TOURISM;
import java.awt.*;
import java.awt.event.*;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.swing.*;

public class Payment extends JFrame{
    Payment(String cost){
        setLayout(null);
        setBounds(245, 50, 800, 600);

        JPanel p1 = new JPanel();
        setContentPane(p1);
        p1.setBackground(Color.WHITE);
        p1.setLayout(null);

        ImageIcon i1  = new ImageIcon(ClassLoader.getSystemResource("icons/payment.jpg"));
        Image i3 = i1.getImage().getScaledInstance(300, 300,Image.SCALE_DEFAULT);
        ImageIcon i2 = new ImageIcon(i3);
        JLabel l0 = new JLabel(i2);
        l0.setBounds(400,80,350,320);
        add(l0);

        JLabel j1 = new JLabel("Contact No: +91 9021242583");
        j1.setForeground(new Color(80, 32, 32));
        j1.setFont(new Font("Candara", 1, 20));
        j1.setBounds(35, 40, 300, 18);
        p1.add(j1);

        JLabel j = new JLabel(cost);
        j.setForeground(new Color(80, 32, 32));
        j.setFont(new Font("Candara", 1, 20));
        j.setBounds(340, 40, 300, 18);
        p1.add(j);

        JLabel j2 = new JLabel("UPI ID: rstours.hdfcbank@paytm");
        j2.setForeground(new Color(80, 32, 32));
        j2.setFont(new Font("Candara", 1, 20));
        j2.setBounds(35, 80, 500, 25);
        p1.add(j2);

        JLabel j3 = new JLabel("Choose location to pay in cash: ");
        j3.setForeground(new Color(80, 32, 32));
        j3.setFont(new Font("Candara", 1, 20));
        j3.setBounds(35, 120, 300, 25);
        p1.add(j3);

        JLabel j4 = new JLabel();
        j4.setForeground(new Color(80, 32, 32));
        j4.setFont(new Font("Candara", 1, 20));
        j4.setBounds(35, 400, 700, 25);
        p1.add(j4);

        JLabel j5 = new JLabel();
        j5.setForeground(new Color(80, 32, 32));
        j5.setFont(new Font("Candara", 1, 20));
        j5.setBounds(35, 200, 700, 25);
        p1.add(j5);

        JLabel j6 = new JLabel();
        j6.setForeground(new Color(80, 32, 32));
        j6.setFont(new Font("Candara", 1, 20));
        j6.setBounds(35, 240, 700, 25);
        p1.add(j6);

        JLabel j7 = new JLabel();
        j7.setForeground(new Color(80, 32, 32));
        j7.setFont(new Font("Candara", 1, 20));
        j7.setBounds(35, 280, 700, 25);
        p1.add(j7);

        Choice c1=new Choice();
        try
        {
            Conn c=new Conn();
            ResultSet rs = c.s.executeQuery("select * from locations");
            while(rs.next())
            {
                if(rs.getString(1).equals("NONE"))
                {
                    continue;
                }
                else
                {
                    c1.add(rs.getString(1));
                }
            }

            rs.close();
        }catch(SQLException e2){}
        c1.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                try{
                    Conn c = new Conn();
                    ResultSet rs = c.s.executeQuery("select * from locations where currentplace = '"+c1.getSelectedItem()+"'");
                    while(rs.next())
                    {
                        j4.setText(rs.getString(2));
                        j5.setText(rs.getString(3));
                        j6.setText(rs.getString(4));
                        j7.setText(rs.getString(5));

                    }
                    rs.close();
                }catch(SQLException e1){}
            }
        });
        c1.setBounds(35, 160, 200, 30);
        add(c1);

        JButton back=new JButton("Back");
        back.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });
        back.setBounds(580, 20, 110, 40);
        back.setForeground(new Color(255, 255, 255));
        back.setBackground(new Color(3, 2, 2));
        back.setFont(new Font("Candara", 1, 20));
        add(back);
    }
    public static void main(String[] args){
        new Payment( "").setVisible(true);
    }
}
