package TOURISM;
import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class AdminRecords extends JFrame
{
    ResultSet rs;
    Conn c=new Conn();
    ResultSetMetaData rsmd;
    String nameu;
    public AdminRecords() throws SQLException
    {
        setBounds(90, 40, 1100, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(new Color(7, 4, 4, 255));

        JPanel panel=new JPanel();
        panel.setBounds(280,100,770,430);
        panel.setBackground(Color.WHITE);
        panel.setLayout(null);
        add(panel);

        Choice year1 = new Choice();
        year1.setBounds(350,35,90,60);
        String date=String.valueOf(LocalDate.now());
        String delemiter="-";
        String[] detail=date.split(delemiter);
        year1.add(detail[0]);
        for(int i=2018;i<2024;i++)
        {
            year1.add(String.valueOf(i));
        }
        panel.add(year1);

        Choice date1= new Choice();
        date1.setBounds(550,35,90,60);
        date1.add(detail[2]);
        panel.add(date1);

        Choice month1 = new Choice();
        switch (detail[1])
        {
            case "01" :
                month1.add("JANUARY");
                break;
            case "02" :
                month1.add("FEBRUARY");
                break;
            case "03" :
                month1.add("MARCH");
                break;
            case "04" :
                month1.add("APRIL");
                break;
            case "05" :
                month1.add("MAY");
                break;
            case "06" :
                date1.add("JUNE");
                break;
            case "07" :
                month1.add("JULY");
                break;
            case "08" :
                month1.add("AUGUST");
                break;
            case "09" :
                month1.add("SEPTEMBER");
                break;
            case "10" :
                month1.add("OCTOBER");
                break;
            case "11" :
                month1.add("NOVEMBER");
                break;
            case "12" :
                date1.add("DECEMBER");
                break;
        }
        month1.add("JANUARY");
        month1.add("FEBRUARY");
        month1.add("MARCH");
        month1.add("APRIL");
        month1.add("MAY");
        month1.add("JUNE");
        month1.add("JULY");
        month1.add("AUGUST");
        month1.add("SEPTEMBER");
        month1.add("OCTOBER");
        month1.add("NOVEMBER");
        month1.add("DECEMBER");
        month1.setBounds(450,35,90,60);
        month1.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e)
            {
                date1.removeAll();
                int i;
                switch (month1.getSelectedItem())
                {
                    case "JANUARY" :
                        for(i=1;i<=31;i++)
                        {
                            date1.add(String.valueOf(i));
                        }
                        break;
                    case "FEBRUARY" :
                        for(i=1;i<=28;i++)
                        {
                            date1.add(String.valueOf(i));
                        }
                        break;
                    case "MARCH" :
                        for(i=1;i<=31;i++)
                        {
                            date1.add(String.valueOf(i));
                        }
                        break;
                    case "APRIL" :
                        for(i=1;i<=30;i++)
                        {
                            date1.add(String.valueOf(i));
                        }
                        break;
                    case "MAY" :
                        for(i=1;i<=31;i++)
                        {
                            date1.add(String.valueOf(i));
                        }
                        break;
                    case "JUNE" :
                        for(i=1;i<=30;i++)
                        {
                            date1.add(String.valueOf(i));
                        }
                        break;
                    case "JULY" :
                        for(i=1;i<=31;i++)
                        {
                            date1.add(String.valueOf(i));
                        }
                        break;
                    case "AUGUST" :
                        for(i=1;i<=31;i++)
                        {
                            date1.add(String.valueOf(i));
                        }
                        break;
                    case "SEPTEMBER" :
                        for(i=1;i<=30;i++)
                        {
                            date1.add(String.valueOf(i));
                        }
                        break;
                    case "OCTOBER" :
                        for(i=1;i<=31;i++)
                        {
                            date1.add(String.valueOf(i));
                        }
                        break;
                    case "NOVEMBER" :
                        for(i=1;i<=30;i++)
                        {
                            date1.add(String.valueOf(i));
                        }
                        break;
                    case "DECEMBER" :
                        for(i=1;i<=31;i++)
                        {
                            date1.add(String.valueOf(i));
                        }
                        break;
                }
            }
        });
        panel.add(month1);

        JLabel managerhead=new JLabel("ADMIN RECORDS");
        managerhead.setFont(new Font("STENCIL",0,40));
        managerhead.setBounds(20,20,350,60);
        managerhead.setForeground(new Color(0, 0, 0));
        panel.add(managerhead);

        JPanel tablep=new JPanel();
        tablep.setBounds(0,80,770,350);
        tablep.setBackground(new Color(0, 252, 211));
        tablep.setLayout(new BorderLayout());
        panel.add(tablep);

        JTable packaged=new JTable();
        DefaultTableModel model1= (DefaultTableModel) packaged.getModel();
        //tablep.add(new JScrollPane(packaged));
        ResultSet rs=c.s.executeQuery("select * from adminrecords");
        rsmd=rs.getMetaData();
        packaged.setPreferredSize(new Dimension(770,350));
        int col=rsmd.getColumnCount();
        String data[]=new String[col];
        for(int i=0;i<col;i++)
        {
            data[i]=rsmd.getColumnName(i+1);
            model1.setColumnIdentifiers(data);
        }
        tablep.add(new JScrollPane(packaged));
        while(rs.next())
        {
            String dataa[]={rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4)};
            model1.addRow(dataa);
        }

        JButton show=new JButton("SHOW");
        show.setBackground(Color.BLACK);
        show.setForeground(Color.WHITE);
        show.setBounds(650, 30, 90, 30);
        show.addActionListener(new ActionListener() {
            Conn c1=new Conn();
            public void actionPerformed(ActionEvent e)
            {
                model1.setRowCount(0);
                int a=0;
                String date = null;
                switch (month1.getSelectedItem())
                {
                    case "JANUARY" :
                        a= Integer.parseInt("01");
                        break;
                    case "FEBRUARY" :
                        a= Integer.parseInt("02");
                        break;
                    case "MARCH" :
                        a= Integer.parseInt("03");
                        break;
                    case "APRIL" :
                        a= Integer.parseInt("04");
                        break;
                    case "MAY" :
                        a= Integer.parseInt("05");
                        break;
                    case "JUNE" :
                        a= Integer.parseInt("06");
                        break;
                    case "JULY" :
                        a= Integer.parseInt("07");
                        break;
                    case "AUGUST" :
                        a= Integer.parseInt("08");
                        break;
                    case "SEPTEMBER" :
                        a=Integer.parseInt("09");
                        break;
                    case "OCTOBER" :
                        a=10;
                        break;
                    case "NOVEMBER" :
                        a= 11;
                        break;
                    case "DECEMBER" :
                        a= 12;
                        break;
                }
                if(a<10 && Integer.parseInt(date1.getSelectedItem())<10)
                {
                    date=year1.getSelectedItem()+"-0"+a+"-0"+date1.getSelectedItem();
                }
                else if(a<10 && Integer.parseInt(date1.getSelectedItem())>=10)
                {
                    date=year1.getSelectedItem()+"-0"+a+"-"+date1.getSelectedItem();
                }
                else if(a>=10 && Integer.parseInt(date1.getSelectedItem())<10)
                {
                    date=year1.getSelectedItem()+"-"+a+"-0"+date1.getSelectedItem();
                }
                else
                {
                    date=year1.getSelectedItem()+"-"+a+"-"+date1.getSelectedItem();
                }
                try {
                    ResultSet rs = c.s.executeQuery("select * from adminrecords where Date='" + date + "'");
                    //ResultSet rss=c.s.executeQuery("select * from customer where username='"+rs.getString(1)+"'");
                    while (rs.next())
                    {
                        String elements[]={rs.getString(1),rs.getString(2),rs.getString(3),rs.getString(4)};
                        model1.addRow(elements);
                    }
                }
                catch(Exception ex){}
            }
        });
        panel.add(show);

        JLabel managerd=new JLabel("MANAGER  DASHBOARD");
        managerd.setFont(new Font("STENCIL",0,40));
        managerd.setBounds(350,20,500,60);
        managerd.setForeground(new Color(237, 238, 228));
        add(managerd);

        JButton main=new JButton("DASHBOARD");
        main.setBounds(50,100,200,35);
        main.setFont(new Font("Candara",1,18));
        main.setBackground(Color.WHITE);
        main.setForeground(Color.BLACK);
        add(main);
        main.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                try {
                    new ManagerDashboard().setVisible(true);
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        JButton adminop=new JButton("ADMIN OPERATION");
        adminop.setBounds(50,160,200,35);
        adminop.setFont(new Font("Candara",1,18));
        adminop.setBackground(Color.WHITE);
        adminop.setForeground(Color.BLACK);
        add(adminop);
        adminop.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                try {
                    new ManagerAdminOP().setVisible(true);
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        JButton adminrec=new JButton("ADMIN RECORDS");
        adminrec.setBounds(50,220,200,35);
        adminrec.setFont(new Font("Candara",1,18));
        adminrec.setBackground(Color.WHITE);
        adminrec.setForeground(Color.BLACK);
        add(adminrec);
        adminrec.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                try {
                    new AdminRecords().setVisible(true);
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        JButton packagedetails=new JButton("PACKAGE UPDATES");
        packagedetails.setBounds(50,280,200,35);
        packagedetails.setFont(new Font("Candara",1,18));
        packagedetails.setBackground(Color.WHITE);
        packagedetails.setForeground(Color.BLACK);
        add(packagedetails);
        packagedetails.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                try {
                    new ManagerPackageUpdate().setVisible(true);
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        JButton hoteldetails=new JButton("HOTEL UPDATES");
        hoteldetails.setBounds(50,340,200,35);
        hoteldetails.setFont(new Font("Candara",1,18));
        hoteldetails.setBackground(Color.WHITE);
        hoteldetails.setForeground(Color.BLACK);
        add(hoteldetails);
        hoteldetails.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                try {
                    new ManagerHotelUpdate().setVisible(true);
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        JButton close=new JButton("CLOSE");
        close.setBounds(50,400,200,35);
        close.setFont(new Font("Candara",1,18));
        close.setBackground(Color.WHITE);
        close.setForeground(Color.BLACK);
        add(close);
        close.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null,"HAVE A NICE DAY....!");
                System.exit(0);
            }
        });
        setVisible(true);
    }
    public static void main(String ...s) throws SQLException {
        new AdminRecords().setVisible(true);
    }
}
