package TOURISM;
import java.awt.*;
import java.sql.*;
import javax.swing.*;
import javax.swing.border.Border;

public class AdminGenerated extends JFrame {
    private JPanel content;
    String usernm;

    public static void main(String[] args) throws SQLException
    {
        new AdminGenerated(" ").setVisible(true);
    }

    public AdminGenerated(String name) throws SQLException
    {
        setBounds(200,30,900,600);

        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/ticket.jpeg"));
        Image i2 = i1.getImage().getScaledInstance(900, 700,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel i4 = new JLabel(i3);
        i4.setBounds(0, 0, 900, 700);
        add(i4);

        JLabel l1=new JLabel("WELCOME");
        l1.setForeground(Color.red);
        l1.setFont(new Font("Gabriola", 0, 63));
        l1.setBounds(60,45,300,110);
        i4.add(l1);

        JLabel payrec=new JLabel("PAYMENT RECEIVED:");
        payrec.setForeground(Color.DARK_GRAY);
        payrec.setFont(new Font("Tahoma", Font.BOLD, 16));
        payrec.setBounds(370,20,180,25);
        i4.add(payrec);

        JLabel pdate=new JLabel();
        pdate.setForeground(Color.DARK_GRAY);
        pdate.setFont(new Font("Tahoma", Font.BOLD, 16));
        pdate.setBounds(550,20,180,25);
        i4.add(pdate);

        JLabel namee=new JLabel("NAME:");
        namee.setForeground(Color.DARK_GRAY);
        namee.setFont(new Font("Tahoma", Font.BOLD, 16));
        namee.setBounds(370,50,100,25);
        i4.add(namee);

        JLabel anamee=new JLabel("NONE");
        anamee.setForeground(Color.DARK_GRAY);
        anamee.setFont(new Font("Tahoma", Font.BOLD, 16));
        anamee.setBounds(430,50,500,25);
        i4.add(anamee);

        JLabel pass=new JLabel("NONE:");
        pass.setForeground(Color.DARK_GRAY);
        pass.setFont(new Font("Tahoma", Font.BOLD, 16));
        pass.setBounds(370,80,100,25);
        i4.add(pass);

        JLabel apass=new JLabel("NONE");
        apass.setForeground(Color.DARK_GRAY);
        apass.setFont(new Font("Tahoma", Font.BOLD, 16));
        apass.setBounds(475,80,140,25);
        i4.add(apass);

        JLabel gender=new JLabel("GENDER:");
        gender.setForeground(Color.DARK_GRAY);
        gender.setFont(new Font("Tahoma", Font.BOLD, 16));
        gender.setBounds(630,80,100,25);
        i4.add(gender);

        JLabel agender=new JLabel("NONE");
        agender.setForeground(Color.DARK_GRAY);
        agender.setFont(new Font("Tahoma", Font.BOLD, 16));
        agender.setBounds(710,80,100,25);
        i4.add(agender);

        JLabel country=new JLabel("COUNTRY:");
        country.setForeground(Color.DARK_GRAY);
        country.setFont(new Font("Tahoma", Font.BOLD, 16));
        country.setBounds(370,110,100,25);
        i4.add(country);

        JLabel acountry=new JLabel("NONE");
        acountry.setForeground(Color.DARK_GRAY);
        acountry.setFont(new Font("Tahoma", Font.BOLD, 16));
        acountry.setBounds(465,110,300,25);
        i4.add(acountry);

        JLabel phone=new JLabel("PHONE:");
        phone.setForeground(Color.DARK_GRAY);
        phone.setFont(new Font("Tahoma", Font.BOLD, 16));
        phone.setBounds(630,110,100,25);
        i4.add(phone);

        JLabel aphone=new JLabel("NONE");
        aphone.setForeground(Color.DARK_GRAY);
        aphone.setFont(new Font("Tahoma", Font.BOLD, 16));
        aphone.setBounds(695,110,150,25);
        i4.add(aphone);

        JLabel address=new JLabel("ADDRESS:");
        address.setForeground(Color.DARK_GRAY);
        address.setFont(new Font("Tahoma", Font.BOLD, 16));
        address.setBounds(370,140,100,25);
        i4.add(address);

        JLabel aaddress=new JLabel("NONE");
        aaddress.setForeground(Color.DARK_GRAY);
        aaddress.setFont(new Font("Tahoma", Font.BOLD, 16));
        aaddress.setBounds(455,140,500,25);
        i4.add(aaddress);

        JLabel email=new JLabel("EMAIL:");
        email.setForeground(Color.DARK_GRAY);
        email.setFont(new Font("Tahoma", Font.BOLD, 16));
        email.setBounds(370,170,100,25);
        i4.add(email);

        JLabel aemail=new JLabel("NONE");
        aemail.setForeground(Color.DARK_GRAY);
        aemail.setFont(new Font("Tahoma", Font.BOLD, 16));
        aemail.setBounds(435,170,300,25);
        i4.add(aemail);

        JLabel pack=new JLabel("PACKAGE:");
        pack.setForeground(Color.DARK_GRAY);
        pack.setFont(new Font("Tahoma", Font.BOLD, 16));
        pack.setBounds(370,230,100,25);
        i4.add(pack);

        JLabel apack=new JLabel("NONE");
        apack.setForeground(Color.DARK_GRAY);
        apack.setFont(new Font("Tahoma", Font.BOLD, 16));
        apack.setBounds(460,230,200,25);
        i4.add(apack);

        JLabel person=new JLabel("PERSON:");
        person.setForeground(Color.DARK_GRAY);
        person.setFont(new Font("Tahoma", Font.BOLD, 16));
        person.setBounds(370,260,300,25);
        i4.add(person);

        JLabel aperson=new JLabel("NONE");
        aperson.setForeground(Color.DARK_GRAY);
        aperson.setFont(new Font("Tahoma", Font.BOLD, 16));
        aperson.setBounds(450,260,300,25);
        i4.add(aperson);

        JLabel trans=new JLabel("TRANSPORT:");
        trans.setForeground(Color.DARK_GRAY);
        trans.setFont(new Font("Tahoma", Font.BOLD, 16));
        trans.setBounds(560,260,150,25);
        i4.add(trans);

        JLabel atrans=new JLabel("NONE");
        atrans.setForeground(Color.DARK_GRAY);
        atrans.setFont(new Font("Tahoma", Font.BOLD, 16));
        atrans.setBounds(670,260,300,25);
        i4.add(atrans);

        JLabel aatrans=new JLabel("NONE");
        aatrans.setForeground(Color.DARK_GRAY);
        aatrans.setFont(new Font("Tahoma", Font.BOLD, 16));
        aatrans.setBounds(670,290,300,25);
        i4.add(aatrans);

        JLabel price=new JLabel("COST:");
        price.setForeground(Color.DARK_GRAY);
        price.setFont(new Font("Tahoma", Font.BOLD, 16));
        price.setBounds(370,290,80,25);
        i4.add(price);

        JLabel aprice=new JLabel("NONE");
        aprice.setForeground(Color.DARK_GRAY);
        aprice.setFont(new Font("Tahoma", Font.BOLD, 16));
        aprice.setBounds(425,290,80,25);
        i4.add(aprice);

        JLabel hotel=new JLabel("HOTEL:");
        hotel.setForeground(Color.DARK_GRAY);
        hotel.setFont(new Font("Tahoma", Font.BOLD, 16));
        hotel.setBounds(370,350,100,25);
        i4.add(hotel);

        JLabel ahotel=new JLabel("NONE");
        ahotel.setForeground(Color.DARK_GRAY);
        ahotel.setFont(new Font("Tahoma", Font.BOLD, 16));
        ahotel.setBounds(440,350,500,25);
        i4.add(ahotel);

        JLabel person2=new JLabel("PERSON:");
        person2.setForeground(Color.DARK_GRAY);
        person2.setFont(new Font("Tahoma", Font.BOLD, 16));
        person2.setBounds(370,380,100,25);
        i4.add(person2);

        JLabel aperson2=new JLabel("NONE");
        aperson2.setForeground(Color.DARK_GRAY);
        aperson2.setFont(new Font("Tahoma", Font.BOLD, 16));
        aperson2.setBounds(450,380,100,25);
        i4.add(aperson2);

        JLabel days=new JLabel("DAYS:");
        days.setForeground(Color.DARK_GRAY);
        days.setFont(new Font("Tahoma", Font.BOLD, 16));
        days.setBounds(560,380,100,25);
        i4.add(days);

        JLabel adays=new JLabel("NONE");
        adays.setForeground(Color.DARK_GRAY);
        adays.setFont(new Font("Tahoma", Font.BOLD, 16));
        adays.setBounds(615,380,100,25);
        i4.add(adays);

        JLabel room=new JLabel("ROOM:");
        room.setForeground(Color.DARK_GRAY);
        room.setFont(new Font("Tahoma", Font.BOLD, 16));
        room.setBounds(370,410,100,25);
        i4.add(room);

        JLabel aroom=new JLabel("NONE");
        aroom.setForeground(Color.DARK_GRAY);
        aroom.setFont(new Font("Tahoma", Font.BOLD, 16));
        aroom.setBounds(425,410,100,25);
        i4.add(aroom);

        JLabel food=new JLabel("FOOD:");
        food.setForeground(Color.DARK_GRAY);
        food.setFont(new Font("Tahoma", Font.BOLD, 16));
        food.setBounds(560,410,100,25);
        i4.add(food);

        JLabel afood=new JLabel("NONE");
        afood.setForeground(Color.DARK_GRAY);
        afood.setFont(new Font("Tahoma", Font.BOLD, 16));
        afood.setBounds(615,410,100,25);
        i4.add(afood);

        JLabel cost=new JLabel("COST:");
        cost.setForeground(Color.DARK_GRAY);
        cost.setFont(new Font("Tahoma", Font.BOLD, 16));
        cost.setBounds(370,440,100,25);
        i4.add(cost);

        JLabel acost=new JLabel("NONE");
        acost.setForeground(Color.DARK_GRAY);
        acost.setFont(new Font("Tahoma", Font.BOLD, 16));
        acost.setBounds(425,440,100,25);
        i4.add(acost);

        JLabel total=new JLabel("NONE");
        total.setForeground(Color.black);
        total.setFont(new Font("Tahoma", Font.BOLD, 30));
        total.setBounds(600,500,400,40);
        i4.add(total);

        Conn c=new Conn();
        try {
            int coost = 0;
            int pprice = 0;
            ResultSet rs = c.s.executeQuery("select * from customer where name='" + name + "'");
            while (rs.next()) {
                usernm = rs.getString("username");
                anamee.setText(rs.getString("name"));
                pass.setText(rs.getString("id_type"));
                apass.setText(rs.getString("number"));
                agender.setText(rs.getString("gender"));
                acountry.setText(rs.getString("country"));
                aaddress.setText(rs.getString("address"));
                aphone.setText(rs.getString("phone"));
                aemail.setText(rs.getString("email"));
            }
            rs=c.s.executeQuery("select * from account where username='"+usernm+"'");
            if(rs.next())
            {
                pdate.setText(rs.getString(7));
            }
            rs = c.s.executeQuery("select * from bookpackage where username='" + usernm + "'");
            while (rs.next()) {
                apack.setText(rs.getString(2));
                aperson.setText(rs.getString(3));
                atrans.setText(rs.getString(8));
                aprice.setText(rs.getString(7));
                pprice = Integer.parseInt(rs.getString(7));
                rs = c.s.executeQuery("select * from transport where distance='" + rs.getString(8) +"-"+rs.getString(2)+"'");
                {
                    while (rs.next())
                    {
                        aatrans.setText(rs.getString(2));
                    }
                }
            }
            coost += pprice;
            rs = c.s.executeQuery("select * from bookhotel where username='" + usernm + "'");
            while (rs.next()) {
                ahotel.setText(rs.getString(2));
                aperson2.setText(rs.getString(3));
                adays.setText(rs.getString(4));
                aroom.setText(rs.getString(5));
                afood.setText(rs.getString(6));
                acost.setText(rs.getString(10));
                pprice = Integer.parseInt(rs.getString(10));
            }
            coost += pprice;
            total.setText("" + coost);
            rs.close();
        }
        catch (SQLException ex)
        {
            throw new RuntimeException(ex);
        }
    }
}
