package TOURISM;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AdminAddPackage extends JFrame
{
    public static void main(String[] args)
    {
        new AdminAddPackage().setVisible(true);
    }
    AdminAddPackage()
    {
        setBounds(270, 90, 750, 460);

        JPanel p1 = new JPanel();
        setContentPane(p1);
        p1.setBackground(Color.WHITE);
        p1.setLayout(null);

        JLabel L1 = new JLabel("ADD PACKAGE");
        L1.setFont(new Font("Candara", 1, 30));
        L1.setBounds(280, 20, 200, 35);
        add(L1);

        JLabel l2 = new JLabel("PLACE/CITY NAME: ");
        l2.setFont(new Font("Yu Mincho", Font.PLAIN, 15));
        l2.setBounds(120, 60, 150, 25);
        add(l2);

        JTextField l3 = new JTextField();
        l3.setBounds(270, 60, 220, 25);
        add(l3);

        JLabel l4 = new JLabel("TOTAL COST: ");
        l4.setFont(new Font("Yu Mincho", Font.PLAIN, 15));
        l4.setBounds(120, 330, 150, 25);
        add(l4);

        JLabel l20 = new JLabel("CHANGETO: ");
        l20.setFont(new Font("Yu Mincho", Font.PLAIN, 15));
        l20.setBounds(120, 370, 150, 25);
        add(l20);

        JTextField l5 = new JTextField();
        l5.setBounds(230, 330, 200, 25);
        p1.add(l5);

        TextArea t1 = new TextArea( );//Scrollbar.VERTICAL);
        //t1.setEditable(false);
        t1.setFont(new Font("Candara", 1, 16));
        t1.setBounds(120, 100, 500, 230);
        p1.add(t1);

        /*JTextField l6 = new JTextField();
        l6.setBounds(120, 90, 500, 25);
        p1.add(l6);

        JTextField l7 = new JTextField();
        l7.setBounds(120, 120, 500, 25);
        p1.add(l7);

        JTextField l8 = new JTextField();
        l8.setBounds(120, 150, 500, 25);
        p1.add(l8);

        JTextField l9 = new JTextField();
        l9.setBounds(120, 180, 500, 25);
        p1.add(l9);

        JTextField l10 = new JTextField();
        l10.setBounds(120, 210, 500, 25);
        p1.add(l10);

        JTextField l11 = new JTextField();
        l11.setBounds(120, 240, 500, 25);
        p1.add(l11);

        JTextField l12 = new JTextField();
        l12.setBounds(120, 270, 500, 25);
        p1.add(l12);

        JTextField l13 = new JTextField();
        l13.setBounds(120, 300, 500, 25);
        p1.add(l13);*/

        JButton l14=new JButton("CLICK TO ADD");
        l14.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                Conn c = new Conn();
                try
                {
                    ResultSet rs=c.s.executeQuery("select * from createpackage");
                    while(rs.next())
                    {
                        String comp=l3.getText();
                        if(comp.equals(rs.getString(1)))
                        {
                            //c.s.executeUpdate("delete from createpackage where place='" + rs.getString(1) + "'");
                            JOptionPane.showMessageDialog(null,"PACKAGE ALREADY CREATED YOU CAN IT");
                            return;
                        }
                    }
                    //String query="insert into createpackage values('"+l3.getText()+"','"+l6.getText()+"','"+l7.getText()+"','"+l8.getText()+"','"+l9.getText()+"','"+l10.getText()+"','"+l11.getText()+"','"+l12.getText()+"','"+l13.getText()+"','"+l5.getText()+"')";
                    //c.s.executeUpdate(query);
                    if(t1.getText()=="")
                    {
                        JOptionPane.showMessageDialog(null,"DESCRIPTION IS EMPTY");
                        return;
                    }
                    String query="insert into createpackage values('"+l3.getText()+"','"+t1.getText()+"','"+l5.getText()+"')";
                    c.s.executeUpdate(query);

                    JOptionPane.showMessageDialog(null,"Package Added Successfully");
                    //setVisible(false);
                    //rs.close();
                }
                catch (SQLException ex)
                {
                    throw new RuntimeException(ex);
                }
            }
        });
        l14.setBounds(460, 330, 160, 25);
        l14.setBackground(Color.BLACK);
        l14.setForeground(Color.ORANGE);
        p1.add(l14);

        JButton l15=new JButton("EDIT");
        l15.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                Conn c = new Conn();
                try
                {
                    setVisible(false);
                    new AdminUpdatePackage().setVisible(true);
                    //rs.close();
                }
                catch (SQLException ex)
                {
                    throw new RuntimeException(ex);
                }
            }
        });
        l15.setBounds(230, 370, 100, 25);
        l15.setBackground(Color.BLACK);
        l15.setForeground(Color.ORANGE);
        p1.add(l15);

        JButton l16=new JButton("DELETE");
        l16.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                Conn c = new Conn();
                try
                {
                    setVisible(false);
                    new AdminDeletePackage().setVisible(true);
                    //rs.close();
                }
                catch (SQLException ex)
                {
                    throw new RuntimeException(ex);
                }
            }
        });
        l16.setBounds(400, 370, 100, 25);
        l16.setBackground(Color.BLACK);
        l16.setForeground(Color.ORANGE);
        p1.add(l16);
    }
}
