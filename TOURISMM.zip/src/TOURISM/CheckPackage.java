package TOURISM;
import java.awt.image.BufferedImage;
import java.awt.image.ImageObserver;
import java.awt.image.ImageProducer;
import java.sql.*;
import java.awt.*;
import java.awt.event.*;
import java.util.EventListener;
import javax.swing.*;

public class CheckPackage extends JFrame
{
    public static void main(String[] args)
    {
        new CheckPackage("").setVisible(true);
    }
    String image="";

    CheckPackage(String username)
    {
        setBounds(100, 60, 1100, 600);

        JPanel p1 = new JPanel();
        setContentPane(p1);
        p1.setBackground(Color.WHITE);
        p1.setLayout(null);

        JLabel l1 = new JLabel();
        l1.setFont(new Font("Candara", 1, 35));
        l1.setBounds(50, 10, 400, 53);
        p1.add(l1);

        /*JLabel l2 = new JLabel();
        l2.setForeground(new Color(80, 32, 32));
        l2.setBounds(35, 70, 300, 20);
        l2.setFont(new Font("Candara", 1, 16));
       // p1.add(l2);

        JLabel l3 = new JLabel();
        l3.setForeground(new Color(80, 32, 32));
        l3.setBounds(35, 110, 500, 20);
        l3.setFont(new Font("Candara", 1, 16));
        p1.add(l3);

        JLabel l4 = new JLabel();
        l4.setForeground(new Color(80, 32, 32));
        l4.setBounds(35, 150, 500, 20);
        l4.setFont(new Font("Candara", 1, 16));
        p1.add(l4);

        JLabel l5 = new JLabel();
        l5.setForeground(new Color(80, 32, 32));
        l5.setBounds(35, 190, 500, 20);
        l5.setFont(new Font("Candara", 1, 16));
        p1.add(l5);

        JLabel l6 = new JLabel();
        l6.setForeground(new Color(80, 32, 32));
        l6.setBounds(35, 230, 500, 20);
        l6.setFont(new Font("Candara", 1, 16));
        p1.add(l6);

        JLabel l7 = new JLabel();
        l7.setForeground(new Color(80, 32, 32));
        l7.setBounds(35, 270, 500, 20);
        l7.setFont(new Font("Candara", 1, 16));
        p1.add(l7);

        JLabel l8 = new JLabel();
        l8.setForeground(new Color(80, 32, 32));
        l8.setFont(new Font("Candara", 1, 16));
        l8.setBounds(35, 310, 500, 20);
        p1.add(l8);

        JLabel l9 = new JLabel();
        l9.setForeground(new Color(80, 32, 32));
        l9.setBounds(35, 350, 500, 20);
        l9.setFont(new Font("Candara", 1, 16));
        p1.add(l9);

        JLabel lblDeposite = new JLabel("Package cost:");
        lblDeposite.setFont(new Font("Candara", 1, 30));
        lblDeposite.setBounds(35, 460, 400, 40);
        p1.add(lblDeposite);*/

        TextArea t1 = new TextArea();//Scrollbar.VERTICAL);
        t1.setEditable(false);
        t1.setBackground(new Color(250, 229, 2));
        t1.setFont(new Font("STENCIL", 1, 16));
        t1.setBounds(35, 70, 550, 350);
        p1.add(t1);

        JLabel la2 = new JLabel("Rs");
        la2.setForeground(new Color(80, 32, 32));
        la2.setFont(new Font("Candara", 1, 30));
        la2.setBounds(550, 460, 80, 40);
        p1.add(la2);

        JLabel l10 = new JLabel();
        l10.setForeground(new Color(80, 32, 32));
        l10.setFont(new Font("Candara", 1, 30));
        l10.setBounds(600, 460, 400, 40);
        p1.add(l10);

        JLabel l11 = new JLabel("Select Package: ");
        l11.setFont(new Font("Candara", 1, 20));
        l11.setBounds(600, 25, 150, 90);
        p1.add(l11);

        Choice c0 = new Choice();
        Conn c = new Conn();
        try{

            ResultSet rs = c.s.executeQuery("select * from createpackage");
            while(rs.next())
            {
                c0.add(rs.getString("place"));
            }

            rs.close();
        }catch(SQLException e){}
        c0.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e)
            {

                Conn c = new Conn();
                try
                {
                    ResultSet rs = c.s.executeQuery("select * from createpackage where place = '"+c0.getSelectedItem()+"'");
                    if(rs.next()){
                        l1.setText(rs.getString(1));
                        /*l2.setText(rs.getString(2));
                        l3.setText(rs.getString(3));
                        l4.setText(rs.getString(4));
                        l5.setText(rs.getString(5));
                        l6.setText(rs.getString(6));
                        l7.setText(rs.getString(7));
                        l8.setText(rs.getString(8));
                        l9.setText(rs.getString(9));*/
                        t1.setText(rs.getString(2));
                        l10.setText(rs.getString(3));
                        image=rs.getString(11);
                    }
                }catch(Exception ee){ }
            }
        });
        c0.setBounds(785, 57, 200, 90);
        p1.add(c0);

        JButton lblCheckInStatus = new JButton("BOOK");
        lblCheckInStatus.setForeground(Color.WHITE);
        lblCheckInStatus.setBackground(new Color(80, 32, 32));
        lblCheckInStatus.setFont(new Font("Candara", 1, 20));
        lblCheckInStatus.setBounds(35, 450, 150, 40);
        lblCheckInStatus.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e)
            {
                setVisible(false);
                try {
                    new BookPackage(username).setVisible(true);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });
        p1.add(lblCheckInStatus);

        JButton back=new JButton("Back");
        back.setBackground(new Color(80, 32, 32));
        back.setForeground(Color.WHITE);
        back.setFont(new Font("Candara", 1, 20));
        back.setBounds(200, 450, 150, 40);
        back.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });
        p1.add(back);

        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/beauty1.jpg"));
        Image i3 = i1.getImage().getScaledInstance(550, 300,Image.SCALE_DEFAULT);
        ImageIcon i2 = new ImageIcon(i3);
        JLabel l0 = new JLabel(i2);
        l0.setBounds(600,110,400,320);
        add(l0);

        ImageIcon i4  = new ImageIcon(ClassLoader.getSystemResource("icons/back17.jpg"));
        Image i5 = i4.getImage().getScaledInstance(1100, 600,Image.SCALE_DEFAULT);
        ImageIcon i6 = new ImageIcon(i5);
        JLabel i7 = new JLabel(i6);
        i7.setBounds(0,0,1100,600);
        add(i7);
    }
}
