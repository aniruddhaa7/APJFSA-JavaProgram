package TOURISM;
import java.awt.BorderLayout;
import java.awt.*;
import java.awt.EventQueue;

import javax.swing.border.EmptyBorder;

import java.awt.Font;
import java.awt.Image;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.*;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.time.LocalDate;
import java.time.LocalDateTime;

public class BookPackage extends JFrame implements ActionListener
{
    private JPanel contentPane;
    //Conn c=new Conn();
    JTextField t1,t2;
    int price;
    Conn c = new Conn();
    Choice c1,c2,c3;
    /**
     * Launch the application.
     */
    public static void main(String[] args)
    {
        EventQueue.invokeLater(new Runnable()
        {
            public void run() {
                try
                {
                    BookPackage frame = new BookPackage("");
                    frame.setVisible(true);
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }
            }
        });
    }

    public BookPackage(String username) throws SQLException
    {
        setBounds(350, 80, 600, 550);
        contentPane = new JPanel();
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel booked = new JLabel("BOOKED: ");
        booked.setFont(new Font("Candara", 1, 25));
        booked.setBounds(35, 230, 300, 53);
        contentPane.add(booked);

        JLabel packageselected = new JLabel("Selected Package :");
        packageselected.setBounds(35, 280, 200, 25);
        packageselected.setFont(new Font("Candara", 1, 19));
        contentPane.add(packageselected);

        JLabel packname=new JLabel("");
        packname.setFont(new Font("Candara", 1, 20));
        packname.setBounds(281, 280, 150, 30);
        add(packname);

        JLabel price10=new JLabel("NONE");
        price10.setBounds(450, 280, 200, 20);
        price10.setFont(new Font("Segoe UI", 1, 20));
        contentPane.add(price10);

        JLabel pickup = new JLabel("Pickup location:");
        pickup.setBounds(35, 320, 235, 25);
        pickup.setFont(new Font("Candara", 1, 19));
        contentPane.add(pickup);

        JLabel pick=new JLabel("");
        pick.setFont(new Font("Candara", 1, 20));
        pick.setBounds(281, 320, 150, 30);
        add(pick);

        JLabel price11=new JLabel("NONE");
        price11.setBounds(450, 320, 200, 20);
        price11.setFont(new Font("Segoe UI", 1, 19));
        contentPane.add(price11);

        JLabel totalp = new JLabel("Total Person: ");
        totalp.setBounds(35, 360, 200, 20);
        totalp.setFont(new Font("Candara", 1, 19));
        contentPane.add(totalp);

        JLabel pp=new JLabel("");
        pp.setBounds(281, 360, 150, 20);
        pp.setFont(new Font("Segoe UI", 1, 19));
        contentPane.add(pp);

        JLabel totalpr = new JLabel("Total Price :");
        totalpr.setBounds(35, 400, 200, 20);
        totalpr.setFont(new Font("Candara", 1, 19));
        contentPane.add(totalpr);

        JLabel num = new JLabel("0");
        num.setBounds(281, 400, 200, 20);
        num.setForeground(new Color(80, 32, 32));
        num.setFont(new Font("Segoe UI", 1, 19));
        contentPane.add(num);

        Conn c=new Conn();
        try
        {
            ResultSet rs = c.s.executeQuery("select * from bookpackage where username='"+username+"'");
            if(rs.next())
            {
                packname.setText(rs.getString(2));
                pick.setText(rs.getString(8));
                pp.setText(rs.getString(3));
                num.setText(rs.getString(7));
            }
            rs = c.s.executeQuery("select * from transport where distance = '" + pick.getText() + "-" + packname.getText() + "'");
            if(rs.next())
            {
                price11.setText(rs.getString(2));
            }
            rs = c.s.executeQuery("select * from createpackage where place = '" + packname.getText() + "'");
            while (rs.next())
            {
                price10.setText(rs.getString(10));
            }
        }
        catch(SQLException e)
        {}

        JLabel lblName = new JLabel("BOOK PACKAGE");
        lblName.setFont(new Font("Candara", 1, 30));
        lblName.setBounds(190, 0, 300, 53);
        contentPane.add(lblName);

        JLabel lblId = new JLabel("Selected Package :");
        lblId.setBounds(35, 60, 200, 25);
        lblId.setFont(new Font("Candara", 1, 19));
        contentPane.add(lblId);

        JLabel price0=new JLabel("NONE");
        price0.setBounds(450, 54, 200, 20);
        price0.setFont(new Font("Segoe UI", 1, 20));
        contentPane.add(price0);

        c1 = new Choice();
        try{
            c = new Conn();
            ResultSet rs = c.s.executeQuery("select * from createpackage");
            while(rs.next())
            {
                c1.add(rs.getString(1));
            }

            rs.close();
        }catch(SQLException e2){}
        c1.setBounds(281, 57, 150, 30);
        c1.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e)
            {
                Conn c = new Conn();
                try
                {
                    ResultSet rs=c.s.executeQuery("select * from createpackage where place='"+c1.getSelectedItem()+"'");
                    if(rs.next())
                    {
                        price0.setText(rs.getString(3));
                    }
                }
                catch (SQLException ex)
                {
                    throw new RuntimeException(ex);
                }
            }
        });
        add(c1);

        JLabel lblmove = new JLabel("Your location for transport :");
        lblmove.setBounds(35, 100, 235, 25);
        lblmove.setFont(new Font("Candara", 1, 19));
        contentPane.add(lblmove);

        JLabel price1=new JLabel("NONE");
        price1.setBounds(450, 95, 200, 20);
        price1.setFont(new Font("Segoe UI", 1, 20));
        contentPane.add(price1);

        c2 = new Choice();
        c2.add("NONE");
        c = new Conn();
        try
        {
            ResultSet rs = c.s.executeQuery("select * from locations");
            while(rs.next())
            {
                if(rs.getString(1).equals("NONE"))
                {
                    continue;
                }
                else
                {
                    c2.add(rs.getString(1));
                }
            }
            rs.close();
        }catch(SQLException e2){}
        c2.setBounds(281, 97, 150, 30);
        c2.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e)
            {
                Conn c = new Conn();
                try
                {
                    if(c2.getSelectedItem()!="NONE")
                    {
                        price1.setText("NONE");
                        ResultSet rs = c.s.executeQuery("select * from transport where distance = '" + c2.getSelectedItem() + "-" + c1.getSelectedItem() + "'");
                        while (rs.next())
                        {
                            price1.setText(rs.getString(2));
                        }
                    }
                }
                catch (SQLException ex)
                {
                    throw new RuntimeException(ex);
                }
            }
        });
        add(c2);

        JLabel la3 = new JLabel("Total Person: ");
        la3.setBounds(35, 140, 200, 20);
        la3.setFont(new Font("Candara", 1, 19));
        contentPane.add(la3);

        t1 = new JTextField();
        t1.setText("0");
        t1.setBounds(281, 140, 150, 20);
        contentPane.add(t1);
        t1.setColumns(10);

        JLabel lblDeposite = new JLabel("Total Price :");
        lblDeposite.setBounds(35, 180, 200, 20);
        lblDeposite.setFont(new Font("Candara", 1, 19));
        contentPane.add(lblDeposite);

        JLabel l5 = new JLabel("0");
        l5.setBounds(281, 180, 200, 20);
        l5.setForeground(new Color(80, 32, 32));
        l5.setFont(new Font("Segoe UI", 1, 19));
        contentPane.add(l5);

        JButton b1 = new JButton("Check Price");
        b1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e)
            {
                int cost=0;
                try{
                    Conn c = new Conn();
                    ResultSet rs = c.s.executeQuery("select * from createpackage where place = '"+c1.getSelectedItem()+"'");
                    while(rs.next())
                    {
                        price=Integer.parseInt(rs.getString("price"));
                        cost+=price;
                    }
                    if(c2.getSelectedItem()!="NONE")
                    {
                        price1.setText("NONE");
                        rs = c.s.executeQuery("select * from transport where distance = '" + c2.getSelectedItem() + "-" + c1.getSelectedItem() + "'");
                        while (rs.next())
                        {
                            price1.setText(rs.getString(2));
                            price = Integer.parseInt(rs.getString("price"));
                            cost += price;
                        }
                    }
                    cost *= Integer.parseInt(t1.getText());
                    l5.setText(""+cost);
                    //rs.close();


                }catch(SQLException e1){}
            }
        });
        b1.setBounds(80, 450, 120, 30);
        b1.setBackground(Color.BLACK);
        b1.setForeground(Color.WHITE);
        b1.setFont(new Font("Candara",1,16));
        contentPane.add(b1);


        JButton btnNewButton = new JButton("Book");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Conn c = new Conn();
                try{
                    String s1 = c1.getSelectedItem();

                    ResultSet rs=c.s.executeQuery("select * from bookpackage where username='"+username+"'");
                    if(rs.next())
                    {
                        if(rs.getString(2).equals("NONE"))
                        {
                            c.s.executeUpdate("delete from bookpackage where username='" + username + "'");
                        }
                        else
                        {
                            JOptionPane.showMessageDialog(null,"PACKAGE ALREADY BOOKED");
                            return;
                        }
                    }
                    rs=c.s.executeQuery("select * from customer where username='"+username+"'");
                    if(rs.next())
                    {
                        String date=String.valueOf(LocalDate.now());
                        String q1 = "insert into bookpackage values('"+username+"', '"+c1.getSelectedItem()+"', '"+t1.getText()+"', '"+rs.getString(2)+"', '"+rs.getString(3)+"', '"+rs.getString(8)+"', '"+l5.getText()+"','"+c2.getSelectedItem()+"','"+date+"')";
                        c.s.executeUpdate(q1);
                    }
                    //rs.close();
                    JOptionPane.showMessageDialog(null, "Package Booked Successfully");
                    setVisible(false);
                    new BookPackage(username).setVisible(true);
                }
                catch(Exception ee)
                {
                    System.out.println(ee.getMessage());
                }
            }
        });
        btnNewButton.setBounds(230, 450, 120, 30);
        btnNewButton.setBackground(Color.BLACK);
        btnNewButton.setForeground(Color.WHITE);
        btnNewButton.setFont(new Font("Candara",1,16));
        contentPane.add(btnNewButton);

        JButton btnExit = new JButton("Back");
        btnExit.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                setVisible(false);
                new CheckPackage(username).setVisible(true);
            }
        });
        btnExit.setBounds(380, 450, 120, 30);
        btnExit.setBackground(Color.BLACK);
        btnExit.setForeground(Color.WHITE);
        btnExit.setFont(new Font("Candara",1,16));
        contentPane.add(btnExit);

        ImageIcon i1=new ImageIcon(ClassLoader.getSystemResource("icons/back16.jpg"));
        Image i2= i1.getImage().getScaledInstance(600,550,Image.SCALE_DEFAULT);
        ImageIcon i3=new ImageIcon(i2);
        JLabel i4=new JLabel(i3);
        i4.setBounds(0,0,600,550);
        add(i4);

        getContentPane().setBackground(Color.WHITE);
    }

    @Override
    public void actionPerformed(ActionEvent e)
    {
    }
}