package TOURISM;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

public class ManagerAdminOP extends JFrame
{
    private JTextField textField;
    private JTextField passwordField,upd;
    private JButton up,sh,del,l3;
    public ManagerAdminOP()
    {
        setBounds(190, 40, 950, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(new Color(7, 4, 4, 255));

        JPanel panel=new JPanel();
        panel.setBounds(280,100,580,430);
        panel.setBackground(Color.WHITE);
        panel.setLayout(null);
        add(panel);

        JLabel managerhead=new JLabel("ADMIN OPERATION");
        managerhead.setFont(new Font("STENCIL",0,40));
        managerhead.setBounds(100,20,500,60);
        managerhead.setForeground(new Color(0, 0, 0));
        panel.add(managerhead);

        int x=90;
        int y=95;
        int x2=190;
        int x3=357;

        JLabel l1 = new JLabel("Username : ");
        l1.setBounds(x, y, 95, 24);
        l1.setFont(new Font("Candara", 1, 18));
        panel.add(l1);

        JLabel l2 = new JLabel("Password : ");
        l2.setBounds(x, y+35, 95, 24);
        l2.setFont(new Font("Candara", 1, 18));
        panel.add(l2);

        JLabel user = new JLabel("Username : ");
        user.setBounds(x, y+69, 95, 24);
        user.setFont(new Font("Candara", 1, 18));
        panel.add(user);

        JLabel pass = new JLabel("Password : ");
        pass.setFont(new Font("Candara", 1, 18));
        pass.setBounds(x, y+103, 95, 24);
        panel.add(pass);

        JLabel apass = new JLabel("NONE");
        apass.setBounds(x2, 198, 75, 24);
        apass.setFont(new Font("Candara", 1, 18));
        panel.add(apass);

        textField = new JTextField();
        textField.setBounds(x2, 93, 157, 20);
        panel.add(textField);

        passwordField = new JTextField();
        passwordField.setBounds(x2, 128, 157, 20);
        panel.add(passwordField);

        JTextField upd= new JTextField();
        upd.setBounds(x2, 233, 157, 20);
        panel.add(upd);

        Choice c = new Choice();
        Conn c1 = new Conn();
        try {

            ResultSet rs = c1.s.executeQuery("select * from adminaccount order by adminname asc");
            while (rs.next())
            {
                c.add(rs.getString(1));
            }
            rs.close();
        } catch (SQLException e) {
        }
        c.setBounds(x2, 163, 157, 20);
        panel.add(c);

        JButton l3 = new JButton("ADD");
        l3.addActionListener(new ActionListener()
        {
            Conn c1=new Conn();
            public void actionPerformed(ActionEvent e) {
                try
                {
                    c1.s.executeUpdate("insert into adminaccount values('"+textField.getText()+"','"+passwordField.getText()+"')");
                    c.add(textField.getText());
                    JOptionPane.showMessageDialog(null,"Added Successfully");
                }
                catch (SQLException ex)
                {
                    throw new RuntimeException(ex);
                }
            }
        });
        l3.setForeground(Color.WHITE);
        l3.setBackground(Color.BLACK);
        l3.setBounds(x3, 93, 90, 20);
        panel.add(l3);

        JButton del = new JButton("DELETE");
        del.addActionListener(new ActionListener()
        {
            Conn c1=new Conn();
            public void actionPerformed(ActionEvent e) {
                try
                {
                    c1.s.executeUpdate("delete from adminaccount where adminname='"+c.getSelectedItem()+"'");
                    c.remove(c.getSelectedItem());
                    JOptionPane.showMessageDialog(null,"Deleted Successfully");
                }
                catch (SQLException ex)
                {
                    throw new RuntimeException(ex);
                }
            }
        });
        del.setForeground(Color.WHITE);
        del.setBackground(Color.BLACK);
        del.setBounds(x3, 163, 90, 20);
        panel.add(del);

        JButton sh = new JButton("SHOW");
        sh.addActionListener(new ActionListener()
        {
            Conn c1=new Conn();
            public void actionPerformed(ActionEvent e)
            {
                try {
                    apass.setText("NONE");
                    ResultSet rs = c1.s.executeQuery("select * from adminaccount where adminname='"+c.getSelectedItem()+"'");
                    while (rs.next()) {
                        apass.setText(rs.getString(2));
                    }
                    rs.close();
                } catch (SQLException e1) {
                }
            }
        });
        sh.setForeground(Color.WHITE);
        sh.setBackground(Color.BLACK);
        sh.setBounds(x3, 198, 90, 20);
        panel.add(sh);

        JButton up = new JButton("UPDATE");
        up.addActionListener(new ActionListener()
        {
            Conn c2=new Conn();
            public void actionPerformed(ActionEvent e)
            {
                try {
                    c2.s.executeUpdate("update adminaccount set password='"+upd.getText()+"' where adminname='"+c.getSelectedItem()+"'");
                    JOptionPane.showMessageDialog(null,"Updated Successfully");
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });
        up.setForeground(Color.WHITE);
        up.setBackground(Color.BLACK);
        up.setBounds(x3, 233, 90, 20);
        panel.add(up);

        JLabel managerd=new JLabel("MANAGER  DASHBOARD");
        managerd.setFont(new Font("STENCIL",0,40));
        managerd.setBounds(230,20,500,60);
        managerd.setForeground(new Color(237, 238, 228));
        add(managerd);

        JButton main=new JButton("DASHBOARD");
        main.setBounds(50,100,200,35);
        main.setFont(new Font("Candara",1,18));
        main.setBackground(Color.WHITE);
        main.setForeground(Color.BLACK);
        add(main);
        main.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                try {
                    new ManagerDashboard().setVisible(true);
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        JButton adminop=new JButton("ADMIN OPERATION");
        adminop.setBounds(50,160,200,35);
        adminop.setFont(new Font("Candara",1,18));
        adminop.setBackground(Color.WHITE);
        adminop.setForeground(Color.BLACK);
        add(adminop);
        adminop.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                try {
                    new ManagerAdminOP().setVisible(true);
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        JButton adminrec=new JButton("ADMIN RECORDS");
        adminrec.setBounds(50,220,200,35);
        adminrec.setFont(new Font("Candara",1,18));
        adminrec.setBackground(Color.WHITE);
        adminrec.setForeground(Color.BLACK);
        add(adminrec);
        adminrec.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                try {
                    new AdminRecords().setVisible(true);
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        JButton packagedetails=new JButton("PACKAGE UPDATES");
        packagedetails.setBounds(50,280,200,35);
        packagedetails.setFont(new Font("Candara",1,18));
        packagedetails.setBackground(Color.WHITE);
        packagedetails.setForeground(Color.BLACK);
        add(packagedetails);
        packagedetails.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                try {
                    new ManagerPackageUpdate().setVisible(true);
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        JButton hoteldetails=new JButton("HOTEL UPDATES");
        hoteldetails.setBounds(50,340,200,35);
        hoteldetails.setFont(new Font("Candara",1,18));
        hoteldetails.setBackground(Color.WHITE);
        hoteldetails.setForeground(Color.BLACK);
        add(hoteldetails);
        hoteldetails.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                try {
                    new ManagerHotelUpdate().setVisible(true);
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        JButton close=new JButton("CLOSE");
        close.setBounds(50,400,200,35);
        close.setFont(new Font("Candara",1,18));
        close.setBackground(Color.WHITE);
        close.setForeground(Color.BLACK);
        add(close);
        close.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null,"HAVE A NICE DAY....!");
                System.exit(0);
            }
        });
        setVisible(true);
    }
    public static void main(String ...s)
    {
        new ManagerAdminOP().setVisible(true);
    }
}
