package TOURISM;
import java.awt.*;
import javax.swing.*;
import java.sql.*;
import java.awt.event.*;
import javax.swing.border.*;
public class Signup extends JFrame implements ActionListener
{

    private JPanel contentPane;
    private JTextField textuser,textnum,textname,textans,textcountry,textaddress,textphone,textemail;
    private JPasswordField textpass;
    private JButton b1, b2;
    private JRadioButton rmale,rfemale;
    private JComboBox comboBox,comboid;


    public static void main(String[] args) {
        new Signup().setVisible(true);
    }

    public Signup() {
        setBounds(300, 50, 700, 600);
        contentPane = new JPanel();
        contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
        setContentPane(contentPane);
        contentPane.setBackground(new Color(215, 163, 113));
        contentPane.setBounds(0,0,700,600);
        contentPane.setLayout(null);

        JLabel head=new JLabel("SIGN UP");
        head.setBounds(450,5,400,100);
        head.setForeground(Color.BLACK);
        head.setFont(new Font("STENCIL", 0, 50));
        contentPane.add(head);

        JLabel lblUsername = new JLabel("Name :");
        lblUsername.setForeground(Color.DARK_GRAY);
        lblUsername.setFont(new Font("Segoe UI", 1, 18));
        lblUsername.setBounds(99, 40, 92, 26);
        contentPane.add(lblUsername);

        textname = new JTextField();
        textname.setBounds(265, 45, 148, 20);
        contentPane.add(textname);
        textname.setColumns(10);

        JLabel lblid=new JLabel("ID Type: ");
        lblid.setForeground(Color.DARK_GRAY);
        lblid.setFont(new Font("Segoe UI", 1, 18));
        lblid.setBounds(99, 80, 92, 26);
        contentPane.add(lblid);

        comboid = new JComboBox(new String[]{"Passport","Aadhar card"});
        comboid.setBounds(265,84,150,25);
        comboid.setBackground(Color.WHITE);
        add(comboid);

        JLabel lblnum=new JLabel("Number: ");
        lblnum.setForeground(Color.DARK_GRAY);
        lblnum.setFont(new Font("Segoe UI", 1, 18));
        lblnum.setBounds(99, 120, 92, 26);
        contentPane.add(lblnum);

        textnum = new JTextField();
        textnum.setBounds(265, 126, 148, 20);
        contentPane.add(textnum);
        textnum.setColumns(10);

        JLabel lblgender=new JLabel("Gender: ");
        lblgender.setForeground(Color.DARK_GRAY);
        lblgender.setFont(new Font("Segoe UI", 1, 18));
        lblgender.setBounds(99, 160, 92, 26);
        contentPane.add(lblgender);

        rmale=new JRadioButton("MALE");
        rmale.setBounds(265,164,65,25);
        rmale.setBackground(Color.WHITE);
        add(rmale);

        rfemale=new JRadioButton("FEMALE");
        rfemale.setBounds(330,164,80,25);
        rfemale.setBackground(Color.WHITE);
        add(rfemale);

        ButtonGroup bg=new ButtonGroup();
        bg.add(rmale);
        bg.add(rfemale);

        JLabel lblcountry=new JLabel("Country: ");
        lblcountry.setForeground(Color.DARK_GRAY);
        lblcountry.setFont(new Font("Segoe UI", 1, 18));
        lblcountry.setBounds(99, 200, 92, 26);
        contentPane.add(lblcountry);

        textcountry = new JTextField();
        textcountry.setBounds(265, 206, 148, 20);
        contentPane.add(textcountry);
        textcountry.setColumns(10);

        JLabel lbladdress=new JLabel("State/City: ");
        lbladdress.setForeground(Color.DARK_GRAY);
        lbladdress.setFont(new Font("Segoe UI", 1, 18));
        lbladdress.setBounds(99, 240, 140, 26);
        contentPane.add(lbladdress);

        textaddress = new JTextField();
        textaddress.setBounds(265, 246, 148, 20);
        contentPane.add(textaddress);
        textaddress.setColumns(10);

        JLabel lblphone=new JLabel("Phone: ");
        lblphone.setForeground(Color.DARK_GRAY);
        lblphone.setFont(new Font("Segoe UI", 1, 18));
        lblphone.setBounds(99, 280, 92, 26);
        contentPane.add(lblphone);

        textphone = new JTextField();
        textphone.setBounds(265, 286, 148, 20);
        contentPane.add(textphone);
        textphone.setColumns(10);

        JLabel lblemail=new JLabel("Email: ");
        lblemail.setForeground(Color.DARK_GRAY);
        lblemail.setFont(new Font("Segoe UI", 1, 18));
        lblemail.setBounds(99, 320, 92, 26);
        contentPane.add(lblemail);

        textemail = new JTextField();
        textemail.setBounds(265, 326, 148, 20);
        contentPane.add(textemail);
        textemail.setColumns(10);

        JLabel lblName = new JLabel("Username :");
        lblName.setForeground(Color.DARK_GRAY);
        lblName.setFont(new Font("Segoe UI", 1, 18));
        lblName.setBounds(99, 360, 110, 26);
        contentPane.add(lblName);

        textuser = new JTextField();
        textuser.setBounds(265, 366, 148, 20);
        contentPane.add(textuser);
        textuser.setColumns(10);

        JLabel lblPassword = new JLabel("Password :");
        lblPassword.setForeground(Color.DARK_GRAY);
        lblPassword.setFont(new Font("Segoe UI", 1, 18));
        lblPassword.setBounds(99, 400, 92, 26);
        contentPane.add(lblPassword);

        textpass = new JPasswordField();
        textpass.setBounds(265, 406, 148, 20);
        contentPane.add(textpass);
        textpass.setColumns(10);

        JLabel lblSecurityQuestion = new JLabel("Security Question :");
        lblSecurityQuestion.setForeground(Color.DARK_GRAY);
        lblSecurityQuestion.setFont(new Font("Segoe UI", 1, 18));
        lblSecurityQuestion.setBounds(99, 440, 200, 26);
        contentPane.add(lblSecurityQuestion);

        comboBox = new JComboBox();
        comboBox.setModel(new DefaultComboBoxModel(new String[] { "Your NickName?", "Your Lucky Number?",
                "Your child SuperHero?", "Your childhood Name ?" }));
        comboBox.setBounds(265, 445, 148, 20);
        contentPane.add(comboBox);

        JLabel lblAnswer = new JLabel("Answer :");
        lblAnswer.setForeground(Color.DARK_GRAY);
        lblAnswer.setFont(new Font("Segoe UI", 1, 18));
        lblAnswer.setBounds(99, 480, 92, 26);
        contentPane.add(lblAnswer);

        textans = new JTextField();
        textans.setColumns(10);
        textans.setBounds(265, 486, 148, 20);
        contentPane.add(textans);

        b1 = new JButton("Create");
        b1.setFont(new Font("Candara",0 , 22));
        b1.setBounds(480, 350, 120, 50);
        b1.setBackground(new Color(3, 0, 0));
        b1.setForeground(new Color(227, 252, 0));
        b1.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                if(textuser.getText().isEmpty()|| textnum.getText().isEmpty()||textname.getText().isEmpty()||textcountry.getText().isEmpty()||textaddress.getText().isEmpty()||textphone.getText().isEmpty()||textemail.getText().isEmpty()||textuser.getText().isEmpty()||textpass.getText().isEmpty()||textans.getText().isEmpty())
                {
                    JOptionPane.showMessageDialog(null,"Some Entries are missing");
                    return;
                    //new Signup().setVisible(true);
                }
                Conn c=new Conn();
                String username=textuser.getText();

                String id=(String) comboid.getSelectedItem();

                String pass=textpass.getText();

                if(pass.length()<4)
                {
                    JOptionPane.showMessageDialog(null,"PASSWORD SHOULD BE MINIMUM 4 LETTERS");
                    return;
                }

                String number=textnum.getText();
                if(number.length()==12)
                {
                    for (int i = 0; i < number.length(); i++) {
                        char ch = number.charAt(i);
                        if(Character.isDigit(ch))
                        {
                            continue;
                        }
                        else
                        {
                            JOptionPane.showMessageDialog(null,"INVALID ID NUMBER...");
                            return;
                        }
                    }
                }
                else
                {
                    JOptionPane.showMessageDialog(null,"INVALID ID NUMBER...");
                    return;
                }

                String name=textname.getText();
                for (int i = 0; i < name.length(); i++) {
                    char ch = name.charAt(i);
                    if(Character.isAlphabetic(ch)||Character.isWhitespace(ch))
                    {
                        continue;
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(null,"INVALID NAME...");
                        return;
                    }
                }

                String gender=null;
                String ch=null;
                if(rmale.isSelected())
                {
                    ch="Male";
                }
                else
                {
                    if(rfemale.isSelected())
                    {
                        ch="Female";
                    }
                    else
                    {
                        ch="Not Selected";
                    }
                }
                switch(ch)
                {
                    case "Male":
                        gender="Male";
                        break;
                    case "Female":
                        gender="Female";
                        break;
                    default:
                        JOptionPane.showMessageDialog(null,"SELECT GENDER..");
                        return;
                }
                String country=textcountry.getText();
                String address=textaddress.getText();
                String phone=textphone.getText();
                if(phone.length()==10)
                {
                    for (int i = 0; i < phone.length(); i++) {
                        char chh = phone.charAt(i);
                        if(Character.isDigit(chh))
                        {
                            continue;
                        }
                        else
                        {
                            JOptionPane.showMessageDialog(null,"INVALID PHONE NUMBER...");
                            return;
                        }
                    }
                }
                else
                {
                    JOptionPane.showMessageDialog(null,"INVALID PHONE NUMBER...");
                    return;
                }
                String email=textemail.getText();

                try {
                    ResultSet rs=c.s.executeQuery("select * from account");
                    while(rs.next())
                    {
                        if(rs.getString(1).equals(textuser.getText()))
                        {
                            JOptionPane.showMessageDialog(null,"Username already used choose another");
                            textuser.setText("");
                            return;
                        }
                    }
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                String query="insert into customer values('"+username+"','"+id+"','"+number+"','"+name+"','"+gender+"','"+country+"','"+address+"','"+phone+"','"+email+"')";
                try {
                    c.s.executeUpdate(query);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                String sql = "insert into account values('"+textuser.getText()+"', '"+textname.getText()+"',md5('"+textpass.getText()+"'), '"+(String) comboBox.getSelectedItem()+"', '"+textans.getText()+"','PENDING','2001-10-10')";
                int i= 0;
                try
                {
                    i = c.s.executeUpdate(sql);
                }
                catch (SQLException ex)
                {
                    throw new RuntimeException(ex);
                }
                String q1 = "insert into bookpackage values('"+username+"', 'NONE', 0, 'NONE', 'NONE', 'NONE', '0','NONE','2001/12/12')";
                try {
                    c.s.executeUpdate(q1);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                String q2 = "insert into bookhotel values('"+username+"', 'NONE', '0', '0', 'NONE', 'NONE', 'NONE','0','0','0','2001/12/12')";
                try {
                    c.s.executeUpdate(q2);
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
                if (i > 0)
                {
                    JOptionPane.showMessageDialog(null, "Account Created Successfully ");
                    setVisible(false);
                    new Login().setVisible(true);
                }
                textnum.setText("");
                textname.setText("");
                textcountry.setText("");
                textaddress.setText("");
                textphone.setText("");
                textemail.setText("");
                textuser.setText("");
                textuser.setText("");
                textpass.setText("");
                textans.setText("");
            }
        });
        contentPane.add(b1);

        b2 = new JButton("Back");
        b2.setFont(new Font("Candara",0, 22));
        b2.setBounds(480, 450, 120, 50);
        b2.setBackground(new Color(3, 0, 10));
        b2.setForeground(new Color(227, 252, 0));
        b2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                new Login().setVisible(true);
                //return 0;
            }
        });
        contentPane.add(b2);

        ImageIcon i4 = new ImageIcon(ClassLoader.getSystemResource("icons/back9.jpg"));
        Image i5 = i4.getImage().getScaledInstance(700, 600,Image.SCALE_DEFAULT);
        ImageIcon i6 = new ImageIcon(i5);
        JLabel NewLabel = new JLabel(i6);
        NewLabel.setBounds(0, 0, 700, 600);
        contentPane.add(NewLabel);
    }

    @Override
    public void actionPerformed(ActionEvent e) {

        //return 0;
    }
}
