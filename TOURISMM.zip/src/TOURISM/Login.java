package TOURISM;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.*;
import java.util.Arrays;
import java.util.Base64;
/*File -> Project Structure -> Module -> Dependencie*/
public class Login extends JFrame implements ActionListener
{
    private JPanel panel;   
    private JTextField textField;
    private JPasswordField passwordField;
    private JButton b0,b1,b2,b3;


    public Login()
    {
        setBackground(new Color(255, 255, 204));
        setBounds(300, 150, 700, 400);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        panel = new JPanel();
        panel.setBackground(Color.WHITE);
        setContentPane(panel);
        panel.setLayout(null);

        JLabel j=new JLabel("USER ");
        j.setBounds(300,15,300,30);
        j.setFont(new Font("Candara", 1, 30));
        panel.add(j);

        b0 = new JButton("ADMIN");
        b0.addActionListener(this);
        b0.setForeground(Color.WHITE);
        b0.setFont(new Font("Segoe UI",0,18));
        b0.setBackground(new Color(80, 32, 32));
        b0.setBounds(210, 60, 250, 35);
        b0.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                new AdminLogin().setVisible(true);
            }
        });
        panel.add(b0);

            JLabel l1 = new JLabel("Username : ");
            l1.setBounds(200, 109, 120, 24);
            l1.setFont(new Font("Segoe UI",0,20));
            panel.add(l1);

            JLabel l2 = new JLabel("Password : ");
            l2.setBounds(200, 144, 100, 24);
            l2.setFont(new Font("Segoe UI",0,20));
            panel.add(l2);

            textField = new JTextField();
            textField.setBounds(310, 116, 157, 20);
            panel.add(textField);

            passwordField = new JPasswordField();
            passwordField.setBounds(310, 152, 157, 20);
            panel.add(passwordField);

            JLabel l3 = new JLabel("");
            l3.setBounds(377, 79, 46, 34);
            panel.add(l3);

            JLabel l4 = new JLabel("");
            l4.setBounds(377, 124, 46, 34);
            panel.add(l3);

            b1 = new JButton("LOGIN");
            b1.addActionListener(this);
            b1.setForeground(new Color(255, 235, 205));
            b1.setBackground(new Color(80, 32, 32));
            b1.setFont(new Font("Segoe UI",0,18));
            b1.setBounds(210, 200, 113, 30);
            panel.add(b1);

            b2 = new JButton("SIGNUP");
            b2.addActionListener(this);
            b2.setForeground(new Color(255, 235, 205));
            b2.setBackground(new Color(80, 32, 32));
            b2.setFont(new Font("Segoe UI",0,18));
            b2.setBounds(340, 200, 113, 30);
            panel.add(b2);

            b3 = new JButton("FORGOT PASSWORD");
            b3.addActionListener(this);
            b3.setForeground(new Color(255, 235, 205));
            b3.setBackground(new Color(80, 32, 32));
            b3.setFont(new Font("Segoe UI",0,18));
            b3.setBounds(235, 250, 200, 30);
            panel.add(b3);

        ImageIcon c1 = new ImageIcon(ClassLoader.getSystemResource("icons/back4.jpg"));
        Image i1 = c1.getImage().getScaledInstance(690, 500,Image.SCALE_DEFAULT);
        ImageIcon i2 = new ImageIcon(i1);
        JLabel l6 = new JLabel(i2);
        l6.setBounds(0, 0, 700, 400);
        add(l6);
    }

    public void actionPerformed(ActionEvent ae)
    {
        if(ae.getSource() == b1)
        {
            Boolean status = false;
            try
            {
                Conn con = new Conn();
                //String pass= Arrays.toString(passwordField.getPassword());
                ResultSet rs = con.s.executeQuery("select * from account where username='"+textField.getText()+"' and password=md5('"+passwordField.getText()+"')");
                if (rs.next())
                {
                    //System.out.println(pass);
                    this.setVisible(false);
                    new Home(textField.getText()).setVisible(true);
                }
                else
                    JOptionPane.showMessageDialog(null, "Invalid Login or Password!");
                    passwordField.setText("");
                    return;

            } catch (Exception e2) {
                e2.printStackTrace();
            }
        }
        if(ae.getSource() == b2)
        {
            setVisible(false);
            new Signup().setVisible(true);
        }
        if(ae.getSource() == b3)
        {
            setVisible(false);
            ForgotPassword forgot = new ForgotPassword();
            forgot.setVisible(true);
        }
    }

    public static void main(String[] args)
    {
        new Login().setVisible(true);
    }

}