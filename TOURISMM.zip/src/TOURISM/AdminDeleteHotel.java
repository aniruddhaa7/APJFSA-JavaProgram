package TOURISM;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AdminDeleteHotel extends JFrame
{
    public static void main(String[] args)
    {
        new AdminDeleteHotel().setVisible(true);
    }
    AdminDeleteHotel()
    {
        setBounds(270, 120, 750, 450);

        JPanel p1 = new JPanel();
        setContentPane(p1);
        p1.setBackground(Color.WHITE);
        p1.setLayout(null);

        JLabel L1 = new JLabel("DELETE HOTEL");
        L1.setFont(new Font("", Font.PLAIN, 25));
        L1.setBounds(290, 20, 200, 25);
        add(L1);

        JLabel l0 = new JLabel("HOTEL CODE: ");
        l0.setFont(new Font("Yu Mincho", Font.PLAIN, 15));
        l0.setBounds(90, 60, 150, 25);
        add(l0);

        JLabel l2 = new JLabel("PLACE/CITY NAME: ");
        l2.setFont(new Font("Yu Mincho", Font.PLAIN, 15));
        l2.setBounds(90, 100, 150, 25);
        add(l2);

        JLabel l16 = new JLabel();
        l16.setFont(new Font("Yu Mincho", Font.PLAIN, 15));
        l16.setBounds(250, 100, 260, 25);
        add(l16);

        JLabel l4 = new JLabel("HOTEL NAME: ");
        l4.setFont(new Font("Yu Mincho", Font.PLAIN, 15));
        l4.setBounds(90, 140, 150, 25);
        add(l4);

        JLabel l13 = new JLabel();
        l13.setFont(new Font("Yu Mincho", Font.PLAIN, 15));
        l13.setBounds(250, 140, 260, 25);
        p1.add(l13);

        JLabel l5 = new JLabel("COST PER PERSON: ");
        l5.setFont(new Font("Yu Mincho", Font.PLAIN, 15));
        l5.setBounds(90, 180, 170, 25);
        add(l5);

        JLabel l7 = new JLabel();
        l7.setFont(new Font("Yu Mincho", Font.PLAIN, 15));
        l7.setBounds(250, 180, 370, 25);
        p1.add(l7);

        JLabel l10 = new JLabel("AC ROOM CHARGE: ");
        l10.setFont(new Font("Yu Mincho", Font.PLAIN, 15));
        l10.setBounds(90, 220, 170, 25);
        add(l10);

        JLabel l8 = new JLabel();
        l8.setFont(new Font("Yu Mincho", Font.PLAIN, 15));
        l8.setBounds(250, 220, 370, 25);
        p1.add(l8);

        JLabel l11 = new JLabel("FOOD CHARGE: ");
        l11.setFont(new Font("Yu Mincho", Font.PLAIN, 15));
        l11.setBounds(90, 260, 170, 25);
        add(l11);

        JLabel l9 = new JLabel();
        l9.setFont(new Font("Yu Mincho", Font.PLAIN, 15));
        l9.setBounds(250, 260, 370, 25);
        p1.add(l9);

        Choice l3 = new Choice();
        l3.setBounds(250, 60, 260, 25);
        Conn c=new Conn();
        try
        {
            ResultSet rs=c.s.executeQuery("select * from hotel");
            while(rs.next())
            {
                l3.add(rs.getString(6));
            }
        }
        catch (SQLException ex)
        {
            throw new RuntimeException(ex);
        }
        l3.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                Conn c=new Conn();
                try {
                    ResultSet rs=c.s.executeQuery("select * from hotel where HotelCode='"+l3.getSelectedItem()+"'");
                    while(rs.next())
                    {
                        l13.setText(rs.getString(1));
                        l16.setText(rs.getString(5));
                        l7.setText(rs.getString(2));
                        l8.setText(rs.getString(3));
                        l9.setText(rs.getString(4));
                    }
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });
        p1.add(l3);

        JButton l14=new JButton("CLICK TO DELETE");
        l14.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                Conn c = new Conn();
                try
                {
                    c.s.executeUpdate("delete from hotel where HotelCode='"+l3.getSelectedItem()+"'");
                    JOptionPane.showMessageDialog(null,"Hotel Deleted Successfully");
                    setVisible(false);
                    new AdminDeleteHotel().setVisible(true);
                }
                catch (SQLException ex)
                {
                    throw new RuntimeException(ex);
                }
            }
        });
        l14.setBounds(170, 320, 160, 25);
        l14.setBackground(Color.BLACK);
        l14.setForeground(Color.ORANGE);
        p1.add(l14);

        JButton back=new JButton("Back");
        back.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });
        back.setBounds(420, 320, 100, 25);
        back.setBackground(Color.BLACK);
        back.setForeground(Color.ORANGE);
        add(back);

        JButton l15=new JButton("ADD");
        l15.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                Conn c = new Conn();
                setVisible(false);
                new AdminAddHotel().setVisible(true);
                //rs.close();
            }
        });
        l15.setBounds(170, 360, 100, 25);
        l15.setBackground(Color.BLACK);
        l15.setForeground(Color.ORANGE);
        p1.add(l15);

        JButton l17=new JButton("EDIT");
        l17.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                Conn c = new Conn();
                setVisible(false);
                new AdminUpdateHotel().setVisible(true);
                //rs.close();
            }
        });
        l17.setBounds(420, 360, 100, 25);
        l17.setBackground(Color.BLACK);
        l17.setForeground(Color.ORANGE);
        p1.add(l17);
    }
}
