package TOURISM;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.SQLException;

public class ManagerDashboard extends JFrame
{
    public ManagerDashboard()
    {
        setBounds(190, 40, 900, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(new Color(7, 4, 4, 255));

        JLabel managerd=new JLabel("MANAGER  DASHBOARD");
        managerd.setFont(new Font("STENCIL",0,40));
        managerd.setBounds(230,20,500,60);
        managerd.setForeground(new Color(237, 238, 228));
        add(managerd);

        JPanel panel=new JPanel();
        panel.setBounds(280,100,580,430);
        panel.setBackground(Color.WHITE);
        panel.setLayout(null);
        add(panel);

        JLabel managerhead=new JLabel("WELCOME");
        managerhead.setFont(new Font("Gabriola",0,60));
        managerhead.setBounds(170,20,500,120);
        managerhead.setForeground(new Color(0, 0, 0));
        panel.add(managerhead);

        int x=50;
        int y=95;
        int x2=20;
        int x3=357;

        JLabel l6 = new JLabel("HERE YOU CAN ADD,DELETE,UPDATE OR CHECK");
        l6.setBounds(x, 90, 500, 25);
        l6.setFont(new Font("Candara", 1, x2));
        panel.add(l6);

        JLabel l7 = new JLabel("ADMINS AS WELL AS CHECK THERE LOGIN ACTIVITIES");
        l7.setBounds(x, 120, 500, 25);
        l7.setFont(new Font("Candara", 1, x2));
        panel.add(l7);

        JLabel l8 = new JLabel("YOU WILL GET ALL UPDATES ");
        l8.setBounds(x, 150, 500, 25);
        l8.setFont(new Font("Candara", 1, x2));
        panel.add(l8);

        JLabel l9 = new JLabel("LIKE BOOKING OF PACKAGE ON THE SPECIFIC DAY");
        l9.setBounds(x, 180, 500, 25);
        l9.setFont(new Font("Candara", 1, x2));
        panel.add(l9);

        JLabel l10 = new JLabel("SAME UPDATES OF HOTEL");
        l10.setBounds(x, 210, 500, 25);
        l10.setFont(new Font("Candara", 1, x2));
        panel.add(l10);

        JLabel l11 = new JLabel("BASICALLY THIS INTERFACE PROVIDES ALL REPORTS");
        l11.setBounds(x, 240, 500, 25);
        l11.setFont(new Font("Candara", 1, x2));
        panel.add(l11);

        JButton main=new JButton("DASHBOARD");
        main.setBounds(50,100,200,35);
        main.setFont(new Font("Candara",1,18));
        main.setBackground(Color.WHITE);
        main.setForeground(Color.BLACK);
        add(main);
        main.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                try {
                    new ManagerDashboard().setVisible(true);
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        JButton adminop=new JButton("ADMIN OPERATION");
        adminop.setBounds(50,160,200,35);
        adminop.setFont(new Font("Candara",1,18));
        adminop.setBackground(Color.WHITE);
        adminop.setForeground(Color.BLACK);
        add(adminop);
        adminop.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                try {
                    new ManagerAdminOP().setVisible(true);
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        JButton adminrec=new JButton("ADMIN RECORDS");
        adminrec.setBounds(50,220,200,35);
        adminrec.setFont(new Font("Candara",1,18));
        adminrec.setBackground(Color.WHITE);
        adminrec.setForeground(Color.BLACK);
        add(adminrec);
        adminrec.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                try {
                    new AdminRecords().setVisible(true);
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        JButton packagedetails=new JButton("PACKAGE UPDATES");
        packagedetails.setBounds(50,280,200,35);
        packagedetails.setFont(new Font("Candara",1,18));
        packagedetails.setBackground(Color.WHITE);
        packagedetails.setForeground(Color.BLACK);
        add(packagedetails);
        packagedetails.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                try {
                    new ManagerPackageUpdate().setVisible(true);
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        JButton hoteldetails=new JButton("HOTEL UPDATES");
        hoteldetails.setBounds(50,340,200,35);
        hoteldetails.setFont(new Font("Candara",1,18));
        hoteldetails.setBackground(Color.WHITE);
        hoteldetails.setForeground(Color.BLACK);
        add(hoteldetails);
        hoteldetails.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                try {
                    new ManagerHotelUpdate().setVisible(true);
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        JButton close=new JButton("CLOSE");
        close.setBounds(50,400,200,35);
        close.setFont(new Font("Candara",1,18));
        close.setBackground(Color.WHITE);
        close.setForeground(Color.BLACK);
        add(close);
        close.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null,"HAVE A NICE DAY....!");
                System.exit(0);
            }
        });
        setVisible(true);
    }
    public static void main(String ...s)
    {
        new ManagerDashboard().setVisible(true);
    }
}
