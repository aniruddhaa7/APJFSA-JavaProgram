/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package TOURISM;


import java.awt.BorderLayout;
import java.awt.*;
import java.awt.EventQueue;

import javax.swing.border.EmptyBorder;

import java.awt.Font;
import java.awt.Image;
import java.sql.*;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.time.LocalDate;

public class BookHotel extends JFrame {
    private JPanel contentPane;
    JTextField t1,t2;
    Choice c1,c2,c3,c4;
    /**
     * Launch the application.
     */
    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try {
                    BookHotel frame = new BookHotel("");
                    frame.setVisible(true);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });
    }

    public BookHotel(String username)
    {
        setBounds(350, 30, 600, 700);
        contentPane = new JPanel();
        setContentPane(contentPane);
        contentPane.setLayout(null);

        JLabel lblName = new JLabel("BOOK HOTEL");
        lblName.setFont(new Font("Candara", 1, 30));
        lblName.setBounds(200, 0, 300, 53);
        contentPane.add(lblName);

        JLabel lblId = new JLabel("Select Hotel :");
        lblId.setBounds(35, 60, 200, 25);
        lblId.setFont(new Font("Candara", 1, 19));
        contentPane.add(lblId);

        c1 = new Choice();
        c1.setBounds(281, 57, 150, 30);
        add(c1);

        JLabel la3 = new JLabel("Total Persons:");
        la3.setBounds(35, 100, 235, 25);
        la3.setFont(new Font("Candara", 1, 19));
        contentPane.add(la3);

        JLabel price1=new JLabel("NONE");
        price1.setBounds(450, 95, 200, 20);
        price1.setFont(new Font("Segoe UI", 1, 20));
        contentPane.add(price1);

        t1 = new JTextField();
        t1.setText("0");
        t1.setBounds(281, 97, 150, 20);
        contentPane.add(t1);
        t1.setColumns(10);

        JLabel la4 = new JLabel("Number of Days:");
        la4.setBounds(35, 140, 200, 20);
        la4.setFont(new Font("Candara", 1, 19));
        contentPane.add(la4);

        t2 = new JTextField();
        t2.setText("0");
        t2.setBounds(281, 140, 150, 20);
        contentPane.add(t2);
        t2.setColumns(10);

        JLabel la5 = new JLabel("AC / Non-AC: ");
        la5.setBounds(35, 180, 200, 20);
        la5.setFont(new Font("Candara", 1, 19));
        contentPane.add(la5);

        c2 = new Choice();
        c2.add("AC");
        c2.add("Non-AC");
        c2.setBounds(281, 175, 150, 20);
        add(c2);

        JLabel la6 = new JLabel("Food Included :");
        la6.setBounds(35, 220, 200, 20);
        la6.setFont(new Font("Candara", 1, 19));
        contentPane.add(la6);

        c3 = new Choice();
        c3.add("Yes");
        c3.add("No");
        c3.setBounds(281, 215, 150, 30);
        add(c3);

        JLabel lblDeposite = new JLabel("Total Price :");
        lblDeposite.setBounds(35, 260, 200, 20);
        lblDeposite.setFont(new Font("Candara", 1, 19));
        contentPane.add(lblDeposite);

        JLabel l5 = new JLabel();
        l5.setBounds(271, 260, 200, 20);
        l5.setForeground(new Color(80, 32, 32));
        l5.setFont(new Font("Candara", 1, 19));
        contentPane.add(l5);

        JLabel book = new JLabel("BOOKED: ");
        book.setFont(new Font("Candara", 1, 25));
        book.setBounds(35, 290, 300, 53);
        contentPane.add(book);

        JLabel booked = new JLabel("Selected Hotel :");
        booked.setBounds(35, 340, 200, 25);
        booked.setFont(new Font("Candara", 1, 19));
        contentPane.add(booked);

        JLabel bookedh = new JLabel();
        bookedh.setBounds(281, 340, 200, 30);
        bookedh.setFont(new Font("Candara", 1, 19));
        add(bookedh);

        JLabel totalp = new JLabel("Total Persons:");
        totalp.setBounds(35, 380, 235, 25);
        totalp.setFont(new Font("Candara", 1, 19));
        contentPane.add(totalp);

        JLabel price2=new JLabel("NONE");
        price2.setBounds(450, 380, 200, 20);
        price2.setFont(new Font("Segoe UI", 1, 20));
        contentPane.add(price2);

        JLabel nump = new JLabel();
        nump.setBounds(281, 380, 150, 20);
        nump.setFont(new Font("Candara", 1, 19));
        contentPane.add(nump);

        JLabel dayn = new JLabel("Number of Days:");
        dayn.setBounds(35, 420, 200, 20);
        dayn.setFont(new Font("Candara", 1, 19));
        contentPane.add(dayn);

        JLabel price3=new JLabel("NONE");
        price3.setBounds(450, 420, 200, 20);
        price3.setFont(new Font("Segoe UI", 1, 20));
        contentPane.add(price3);

        JLabel daynn = new JLabel();
        daynn.setBounds(281, 420, 150, 20);
        daynn.setFont(new Font("Candara", 1, 19));
        contentPane.add(daynn);

        JLabel ac = new JLabel("AC / Non-AC: ");
        ac.setBounds(35, 460, 200, 20);
        ac.setFont(new Font("Candara", 1, 19));
        contentPane.add(ac);

        JLabel price4=new JLabel("NONE");
        price4.setBounds(450, 460, 200, 20);
        price4.setFont(new Font("Segoe UI", 1, 20));
        contentPane.add(price4);

        JLabel acc = new JLabel();
        acc.setBounds(281, 460, 150, 20);
        acc.setFont(new Font("Candara", 1, 19));
        add(acc);

        JLabel food = new JLabel("Food Included :");
        food.setBounds(35, 500, 200, 20);
        food.setFont(new Font("Candara", 1, 19));
        contentPane.add(food);

        JLabel price5=new JLabel("NONE");
        price5.setBounds(450, 500, 200, 20);
        price5.setFont(new Font("Segoe UI", 1, 20));
        contentPane.add(price5);

        JLabel foodc = new JLabel();
        foodc.setBounds(281, 500, 150, 30);
        foodc.setFont(new Font("Candara", 1, 19));
        add(foodc);

        JLabel totalpr = new JLabel("Total Price :");
        totalpr.setBounds(35, 540, 200, 20);
        totalpr.setFont(new Font("Candara", 1, 19));
        contentPane.add(totalpr);

        JLabel totalprb = new JLabel();
        totalprb.setBounds(271, 540, 200, 20);
        totalprb.setForeground(new Color(80, 32, 32));
        totalprb.setFont(new Font("Segoe UI", 1, 19));
        contentPane.add(totalprb);

        Conn c=new Conn();
        try
        {
            String packagee=null;
            ResultSet rs=c.s.executeQuery("select * from bookpackage where username='"+username+"'");
            if(rs.next())
            {
                packagee=rs.getString(2);
            }
            rs=c.s.executeQuery("select * from hotel where place='"+packagee+"'");
            while(rs.next())
            {
                c1.add(rs.getString(1));
            }
            rs.close();
        }
        catch(SQLException e)
        {
        }

        c=new Conn();
        try
        {
            String packagee=null;
            ResultSet rs=c.s.executeQuery("select * from bookhotel where username='"+username+"'");
            if(rs.next())
            {
                packagee=rs.getString(2);
                bookedh.setText(rs.getString(2));
                nump.setText(rs.getString(3));
                daynn.setText(rs.getString(4));
                acc.setText(rs.getString(5));
                foodc.setText(rs.getString(6));
                totalprb.setText(rs.getString(10));
            }
            rs=c.s.executeQuery("select * from hotel where name='"+packagee+"'");
            if(rs.next())
            {
                int numpp=Integer.parseInt(nump.getText());
                int rate=Integer.parseInt(rs.getString(2));
                int fooda=Integer.parseInt(rs.getString(4))*numpp;
                int no=numpp*rate;
                price2.setText(String.valueOf(no));
                int dno=no*Integer.parseInt(daynn.getText());
                price3.setText(String.valueOf(dno));
                if(acc.getText().equals("Non-AC"))
                {
                    price4.setText("0");
                }
                else
                {
                    price4.setText(rs.getString(3));
                }
                if(foodc.getText().equals("No"))
                {
                    price5.setText("0");
                }
                else
                {
                    price5.setText(String.valueOf(fooda));
                }
            }
            rs.close();
        }
        catch(SQLException e)
        {
        }

        JButton b1 = new JButton("Check Price");
        b1.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Conn c = new Conn();
                try
                {
                    String s1 = c1.getSelectedItem();
                    String q1 = "select * from hotel where name = '"+c1.getSelectedItem()+"'";
                    ResultSet rs = c.s.executeQuery(q1);
                    if(rs.next()){

                        int cost = Integer.parseInt(rs.getString("costperperson"));
                        int food = Integer.parseInt(rs.getString("foodincluded"));
                        int ac = Integer.parseInt(rs.getString("acroom"));

                        int persons = Integer.parseInt(t1.getText());
                        int days = Integer.parseInt(t2.getText());

                        String acprice = c2.getSelectedItem();
                        String foodprice = c3.getSelectedItem();
                        int cp=cost*persons;

                        if(persons * days > 0)
                        {
                            int total = 0;
                            total += cp*days;
                            total += acprice.equals("AC") ? ac : 0;
                            total += foodprice.equals("Yes") ? food*persons : 0;
                            l5.setText(""+total);
                        }


                    }

                }catch(Exception ee){
                    System.out.println(ee.getMessage());
                }
            }
        });
        b1.setBounds(80, 570, 120, 30);
        b1.setBackground(Color.BLACK);
        b1.setForeground(Color.WHITE);
        b1.setFont(new Font("Candara",1,16));
        contentPane.add(b1);


        JButton btnNewButton = new JButton("Book");
        btnNewButton.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e)
            {
                Conn c = new Conn();
                try
                {
                    ResultSet rs=c.s.executeQuery("select * from bookhotel where username='"+username+"'");
                    if(rs.next())
                    {
                        if(rs.getString(2).equals("NONE"))
                        {
                            c.s.executeUpdate("delete from bookhotel where username='" + username + "'");
                        }
                        else
                        {
                            JOptionPane.showMessageDialog(null,"HOTEL ALREADY BOOKED");
                            return;
                        }
                    }
                    rs=c.s.executeQuery("select * from customer where username='"+username+"'");
                    if(rs.next())
                    {
                        String date=String.valueOf(LocalDate.now());
                        c.s.executeUpdate("insert into bookhotel values('"+username+"','"+c1.getSelectedItem()+"','"+t1.getText()+"','"+t2.getText()+"','"+c2.getSelectedItem()+"','"+c3.getSelectedItem()+"','"+rs.getString(2)+"','"+rs.getString(3)+"','"+rs.getString(8)+"','"+l5.getText()+"','"+date+"')");
                    }
                    JOptionPane.showMessageDialog(null, "Hotel Booked Successfully");
                    setVisible(false);
                    new BookHotel(username).setVisible(true);
                }
                catch(Exception ee){}
            }
        });
        btnNewButton.setBounds(230, 570, 120, 30);
        btnNewButton.setBackground(Color.BLACK);
        btnNewButton.setForeground(Color.WHITE);
        btnNewButton.setFont(new Font("Candara",1,16));
        contentPane.add(btnNewButton);

        JButton btnExit = new JButton("Back");
        btnExit.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
            }
        });
        btnExit.setBounds(380, 570, 120, 30);
        btnExit.setBackground(Color.BLACK);
        btnExit.setForeground(Color.WHITE);
        btnExit.setFont(new Font("Candara",1,16));
        contentPane.add(btnExit);

        ImageIcon i1  = new ImageIcon(ClassLoader.getSystemResource("icons/back28.jpg"));
        Image i3 = i1.getImage().getScaledInstance(600, 700,Image.SCALE_DEFAULT);
        ImageIcon i2 = new ImageIcon(i3);
        JLabel la1 = new JLabel(i2);
        la1.setBounds(0,0,600,700);
        add(la1);

        getContentPane().setBackground(Color.WHITE);
    }
}
