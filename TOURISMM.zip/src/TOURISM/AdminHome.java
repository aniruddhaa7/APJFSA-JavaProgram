package TOURISM;
import java.awt.*;
import javax.swing.*;
import java.awt.event.*;
import java.sql.SQLException;
import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;

public class AdminHome extends JFrame{
    String username;
    public static void main(String[] args)
    {
        new AdminHome("","").setVisible(true);
    }

    public AdminHome(String username,String inTime) {
        super("Travel and Tourism Management System");
        this.username = username;
        setForeground(Color.CYAN);
        setLayout(null);

        JLabel l1 = new JLabel("RS Tours and Travels");
        l1.setForeground(Color.BLACK);
        l1.setFont(new Font("STENCIL", 0, 65));
        l1.setBounds(400, 20, 1100, 100);
        add(l1);

        JButton m1 = new JButton(" CUSTOMERS");
        m1.setForeground(new Color(19, 19, 13));
        //m1.setIcon(new ImageIcon(getClass().getResource("/icons/customer11.jpg")));
        m1.setFont(new Font("Candara ", 1, 20));
        m1.setBounds(70,40,170,50);
        m1.setForeground(new Color(19, 14, 14));
        m1.setBackground(new Color(250, 245, 2));
        m1.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent ae){
                try{
                    new AdminCustomerDetails().setVisible(true);
                }catch(Exception e ){}
            }
        });
        add(m1);

        JButton M2 = new JButton(" PACKAGES");
        M2.setForeground(new Color(19, 19, 13));
        //m1.setIcon(new ImageIcon(getClass().getResource("/icons/customer11.jpg")));
        M2.setFont(new Font("Candara ", 1, 20));
        M2.setBounds(70,100,170,50);
        M2.setForeground(new Color(19, 14, 14));
        M2.setBackground(new Color(30, 213, 218));
        M2.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent ae){
                try{
                    new AdminAddPackage().setVisible(true);
                }catch(Exception e ){}
            }
        });
        add(M2);

        JButton M3 = new JButton(" HOTELS");
        M3.setForeground(new Color(19, 19, 13));
        //m1.setIcon(new ImageIcon(getClass().getResource("/icons/customer11.jpg")));
        M3.setFont(new Font("Candara ", 1, 20));
        M3.setBounds(70,160,170,50);
        M3.setForeground(new Color(19, 14, 14));
        M3.setBackground(new Color(250, 245, 2));
        M3.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent ae){
                try{
                    new AdminAddHotel().setVisible(true);
                }catch(Exception e ){}
            }
        });
        add(M3);

        JButton M4 = new JButton(" TRANSPORT");
        M4.setForeground(new Color(19, 19, 13));
        //m1.setIcon(new ImageIcon(getClass().getResource("/icons/customer11.jpg")));
        M4.setFont(new Font("Candara ", 1, 20));
        M4.setBounds(70,220,170,50);
        M4.setForeground(new Color(19, 14, 14));
        M4.setBackground(new Color(30, 213, 218));
        M4.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent ae){
                try{
                    new AdminTransport().setVisible(true);
                }catch(Exception e ){}
            }
        });
        add(M4);

        JButton M5 = new JButton(" BRANCHS");
        M5.setForeground(new Color(19, 19, 13));
        //m1.setIcon(new ImageIcon(getClass().getResource("/icons/customer11.jpg")));
        M5.setFont(new Font("Candara ", 1, 20));
        M5.setBounds(70,280,170,50);
        M5.setForeground(new Color(19, 14, 14));
        M5.setBackground(new Color(250, 245, 2));
        M5.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent ae){
                try{
                    new AdminAddBranch().setVisible(true);
                }catch(Exception e ){}
            }
        });
        add(M5);

        JButton M6 = new JButton("CALCULATE");
        M6.setForeground(new Color(19, 19, 13));
        //m1.setIcon(new ImageIcon(getClass().getResource("/icons/customer11.jpg")));
        M6.setFont(new Font("Candara ", 1, 20));
        M6.setBounds(70,340,170,50);
        M6.setForeground(new Color(19, 14, 14));
        M6.setBackground(new Color(30, 213, 218));
        M6.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent ae){
                try{
                    Runtime.getRuntime().exec("calc.exe");
                }catch(Exception e){ }
            }
        });
        add(M6);

        JButton M7 = new JButton("NOTES");
        M7.setForeground(new Color(19, 19, 13));
        //m1.setIcon(new ImageIcon(getClass().getResource("/icons/customer11.jpg")));
        M7.setFont(new Font("Candara ", 1, 20));
        M7.setBounds(70,400,170,50);
        M7.setForeground(new Color(19, 14, 14));
        M7.setBackground(new Color(250, 245, 2));
        M7.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent ae){
                try{
                    Runtime.getRuntime().exec("notepad.exe");
                }catch(Exception e){ }
            }
        });
        add(M7);

        JButton M8 = new JButton("MAKE TICKET");
        M8.setForeground(new Color(19, 19, 13));
        M8.setFont(new Font("Candara ", 1, 20));
        M8.setBounds(70,460,170,50);
        M8.setForeground(new Color(19, 14, 14));
        M8.setBackground(new Color(30, 213, 218));
        M8.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent ae){
                try {
                    new AdminTicket().setVisible(true);
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
        });
        add(M8);

        JButton M9 = new JButton(" LOGOUT ");
        M9.setForeground(new Color(19, 19, 13));
        //m1.setIcon(new ImageIcon(getClass().getResource("/icons/customer11.jpg")));
        M9.setFont(new Font("Candara ", 1, 20));
        M9.setBounds(70,520,170,50);
        M9.setForeground(new Color(19, 14, 14));
        M9.setBackground(new Color(250, 245, 2));
        M9.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent ae){
                String outTime=String.valueOf(LocalTime.now());
                String date=String.valueOf(LocalDate.now());
                Conn c=new Conn();
                try
                {
                    c.s.executeUpdate("insert into adminrecords values('"+username+"','"+inTime+"','"+outTime+"','"+date+"')");
                }
                catch (SQLException e)
                {
                    throw new RuntimeException(e);
                }
                setVisible(false);
                new AdminLogin().setVisible(true);
            }
        });
        add(M9);

        ImageIcon i1 = new ImageIcon(ClassLoader.getSystemResource("icons/adminhome.jpg"));
        Image i2 = i1.getImage().getScaledInstance(1281, 680,Image.SCALE_DEFAULT);
        ImageIcon i3 = new ImageIcon(i2);
        JLabel NewLabel = new JLabel(i3);
        NewLabel.setBounds(0, 0, 1281, 680);
        add(NewLabel);

        setExtendedState(JFrame.MAXIMIZED_BOTH);
        setVisible(true);
        getContentPane().setBackground(Color.WHITE);
    }
}
