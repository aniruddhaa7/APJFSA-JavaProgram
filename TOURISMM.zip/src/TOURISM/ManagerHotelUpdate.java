package TOURISM;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.LocalDate;

public class ManagerHotelUpdate extends JFrame
{
    private JTextField textField;
    private JTextField passwordField,upd;
    private JButton up,sh,del,l3;
    public ManagerHotelUpdate()
    {
        setBounds(90, 40, 1100, 600);
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLayout(null);
        getContentPane().setBackground(new Color(7, 4, 4, 255));

        JPanel panel=new JPanel();
        panel.setBounds(280,100,770,430);
        panel.setBackground(Color.WHITE);
        panel.setLayout(null);
        add(panel);

        JLabel managerhead=new JLabel("HOTEL  UPDATES");
        managerhead.setFont(new Font("STENCIL",0,40));
        managerhead.setBounds(230,10,500,40);
        managerhead.setForeground(new Color(0, 0, 0));
        panel.add(managerhead);

        int i=0;
        int x=60;
        int y=95;
        int x2=210;
        int x3=400;

        JLabel place = new JLabel("SELECT PLACE : ");
        place.setBounds(x, 60, 150, 24);
        place.setFont(new Font("Candara", 1, 18));
        panel.add(place);

        JLabel select = new JLabel("SELECT HOTEL : ");
        select.setBounds(x, y, 150, 24);
        select.setFont(new Font("Candara", 1, 18));
        panel.add(select);

        JLabel year = new JLabel("YEAR : ");
        year.setBounds(x, y+35, 95, 24);
        year.setFont(new Font("Candara", 1, 18));
        panel.add(year);

        JLabel month = new JLabel("MONTH : ");
        month.setBounds(x, y+69, 95, 24);
        month.setFont(new Font("Candara", 1, 18));
        panel.add(month);

        JLabel day = new JLabel("DAY : ");
        day.setFont(new Font("Candara", 1, 18));
        day.setBounds(x, y+103, 95, 24);
        panel.add(day);

        JLabel booking = new JLabel("NO OF BOOKINGS : ");
        booking.setFont(new Font("Candara", 1, 18));
        booking.setBounds(x, y+137, 155, 24);
        panel.add(booking);

        JLabel showbooking = new JLabel("0");
        showbooking.setFont(new Font("Arial Black", 0, 18));
        showbooking.setBounds(x2+10, y+133, 155, 24);
        panel.add(showbooking);

        JLabel date2 = new JLabel();
        date2.setFont(new Font("Arial Black", 0, 18));
        date2.setBounds(385, y+66, 110, 24);
        panel.add(date2);

        Choice select1 = new Choice();
        select1.setBounds(x2, 93, 207, 20);
        panel.add(select1);

        Choice selectp = new Choice();
        selectp.setBounds(x2, 58, 207, 20);
        Conn c=new Conn();
        try {
            ResultSet rs = c.s.executeQuery("select * from locations");
            while (rs.next())
            {
                if(rs.getString(1).equals("NONE"))
                {
                    continue;
                }
                else
                {
                    selectp.add(rs.getString(1));
                }
            }
        }
        catch(Exception ex){}
        selectp.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                Conn c=new Conn();
                try
                {
                    select1.removeAll();
                    ResultSet rs = c.s.executeQuery("select * from hotel where place='"+selectp.getSelectedItem()+"'");
                    while (rs.next())
                    {
                        select1.add(rs.getString(1));
                    }
                }
                catch(Exception ex){}
            }
        });
        panel.add(selectp);

        Choice year1 = new Choice();
        year1.setBounds(x2, 128, 157, 20);
        String date=String.valueOf(LocalDate.now());
        String delemiter="-";
        String[] detail=date.split(delemiter);
        year1.add(detail[0]);
        for(i=2018;i<2024;i++)
        {
            year1.add(String.valueOf(i));
        }
        panel.add(year1);

        Choice date1= new Choice();
        date1.setBounds(x2, 198, 157, 20);
        date1.add(detail[2]);
        panel.add(date1);

        Choice month1 = new Choice();
        switch (detail[1])
        {
            case "01" :
                month1.add("JANUARY");
                break;
            case "02" :
                month1.add("FEBRUARY");
                break;
            case "03" :
                month1.add("MARCH");
                break;
            case "04" :
                month1.add("APRIL");
                break;
            case "05" :
                month1.add("MAY");
                break;
            case "06" :
                date1.add("JUNE");
                break;
            case "07" :
                month1.add("JULY");
                break;
            case "08" :
                month1.add("AUGUST");
                break;
            case "09" :
                month1.add("SEPTEMBER");
                break;
            case "10" :
                month1.add("OCTOBER");
                break;
            case "11" :
                month1.add("NOVEMBER");
                break;
            case "12" :
                date1.add("DECEMBER");
                break;
        }
        month1.add("JANUARY");
        month1.add("FEBRUARY");
        month1.add("MARCH");
        month1.add("APRIL");
        month1.add("MAY");
        month1.add("JUNE");
        month1.add("JULY");
        month1.add("AUGUST");
        month1.add("SEPTEMBER");
        month1.add("OCTOBER");
        month1.add("NOVEMBER");
        month1.add("DECEMBER");
        month1.setBounds(x2, 163, 157, 20);
        month1.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e)
            {
                date1.removeAll();
                int i;
                switch (month1.getSelectedItem())
                {
                    case "JANUARY" :
                        for(i=1;i<=31;i++)
                        {
                            date1.add(String.valueOf(i));
                        }
                        break;
                    case "FEBRUARY" :
                        for(i=1;i<=28;i++)
                        {
                            date1.add(String.valueOf(i));
                        }
                        break;
                    case "MARCH" :
                        for(i=1;i<=31;i++)
                        {
                            date1.add(String.valueOf(i));
                        }
                        break;
                    case "APRIL" :
                        for(i=1;i<=30;i++)
                        {
                            date1.add(String.valueOf(i));
                        }
                        break;
                    case "MAY" :
                        for(i=1;i<=31;i++)
                        {
                            date1.add(String.valueOf(i));
                        }
                        break;
                    case "JUNE" :
                        for(i=1;i<=30;i++)
                        {
                            date1.add(String.valueOf(i));
                        }
                        break;
                    case "JULY" :
                        for(i=1;i<=31;i++)
                        {
                            date1.add(String.valueOf(i));
                        }
                        break;
                    case "AUGUST" :
                        for(i=1;i<=31;i++)
                        {
                            date1.add(String.valueOf(i));
                        }
                        break;
                    case "SEPTEMBER" :
                        for(i=1;i<=30;i++)
                        {
                            date1.add(String.valueOf(i));
                        }
                        break;
                    case "OCTOBER" :
                        for(i=1;i<=31;i++)
                        {
                            date1.add(String.valueOf(i));
                        }
                        break;
                    case "NOVEMBER" :
                        for(i=1;i<=30;i++)
                        {
                            date1.add(String.valueOf(i));
                        }
                        break;
                    case "DECEMBER" :
                        for(i=1;i<=31;i++)
                        {
                            date1.add(String.valueOf(i));
                        }
                        break;
                }
            }
        });
        panel.add(month1);

        JPanel tablep=new JPanel();
        tablep.setBounds(0,260,770,170);
        tablep.setBackground(new Color(0, 252, 211));
        tablep.setLayout(new BorderLayout());
        panel.add(tablep);

        JTable packaged=new JTable();
        DefaultTableModel model1= (DefaultTableModel) packaged.getModel();
        model1.setColumnIdentifiers(new String[]{"NAME","CONTACT","PERSON","DAYS","AC","FOOD","AMOUNT"});
        tablep.add(new JScrollPane(packaged));

        JButton l3 = new JButton("SHOW");
        l3.addActionListener(new ActionListener()
        {
            Conn c1=new Conn();
            public void actionPerformed(ActionEvent e)
            {
                model1.setRowCount(0);
                if(date1.getSelectedItem()==null)
                {
                    JOptionPane.showMessageDialog(null,"DAY FIELD IS EMPTY");
                    return;
                }
                int a=0;
                int booked=0;
                int i;
                String date = null;
                switch (month1.getSelectedItem())
                {
                    case "JANUARY" :
                        a= Integer.parseInt("01");
                        break;
                    case "FEBRUARY" :
                        a= Integer.parseInt("02");
                        break;
                    case "MARCH" :
                        a= Integer.parseInt("03");
                        break;
                    case "APRIL" :
                        a= Integer.parseInt("04");
                        break;
                    case "MAY" :
                        a= Integer.parseInt("05");
                        break;
                    case "JUNE" :
                        a= Integer.parseInt("06");
                        break;
                    case "JULY" :
                        a= Integer.parseInt("07");
                        break;
                    case "AUGUST" :
                        a= Integer.parseInt("08");
                        break;
                    case "SEPTEMBER" :
                        a=Integer.parseInt("09");
                        break;
                    case "OCTOBER" :
                        a=10;
                        break;
                    case "NOVEMBER" :
                        a= 11;
                        break;
                    case "DECEMBER" :
                        a= 12;
                        break;
                }
                if(a<10 && Integer.parseInt(date1.getSelectedItem())<10)
                {
                    date=year1.getSelectedItem()+"-0"+a+"-0"+date1.getSelectedItem();
                }
                else if(a<10 && Integer.parseInt(date1.getSelectedItem())>=10)
                {
                    date=year1.getSelectedItem()+"-0"+a+"-"+date1.getSelectedItem();
                }
                else if(a>=10 && Integer.parseInt(date1.getSelectedItem())<10)
                {
                    date=year1.getSelectedItem()+"-"+a+"-0"+date1.getSelectedItem();
                }
                else
                {
                    date=year1.getSelectedItem()+"-"+a+"-"+date1.getSelectedItem();
                }
                date2.setText(date);
                try {
                    ResultSet rs = c.s.executeQuery("select * from bookhotel where name='" + select1.getSelectedItem() + "' AND booked='"+date+"'");
                    //ResultSet rss=c.s.executeQuery("select * from customer where username='"+rs.getString(1)+"'");
                    while (rs.next())
                    {
                        String elements[]={rs.getString(1),rs.getString(9),rs.getString(3),rs.getString(4),rs.getString(5),rs.getString(6),rs.getString(10)};
                        model1.addRow(elements);
                        booked = booked + 1;
                    }
                    showbooking.setText(String.valueOf(booked));
                }
                catch(Exception ex){}
            }
        });
        l3.setBackground(Color.BLACK);
        l3.setForeground(Color.WHITE);
        l3.setBounds(x3+30, 93, 90, 40);
        panel.add(l3);

        JLabel managerd=new JLabel("MANAGER  DASHBOARD");
        managerd.setFont(new Font("STENCIL",0,40));
        managerd.setBounds(350,20,500,60);
        managerd.setForeground(new Color(237, 238, 228));
        add(managerd);

        JButton main=new JButton("DASHBOARD");
        main.setBounds(50,100,200,35);
        main.setFont(new Font("Candara",1,18));
        main.setBackground(Color.WHITE);
        main.setForeground(Color.BLACK);
        add(main);
        main.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                try {
                    new ManagerDashboard().setVisible(true);
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        JButton adminop=new JButton("ADMIN OPERATION");
        adminop.setBounds(50,160,200,35);
        adminop.setFont(new Font("Candara",1,18));
        adminop.setBackground(Color.WHITE);
        adminop.setForeground(Color.BLACK);
        add(adminop);
        adminop.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                try {
                    new ManagerAdminOP().setVisible(true);
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        JButton adminrec=new JButton("ADMIN RECORDS");
        adminrec.setBounds(50,220,200,35);
        adminrec.setFont(new Font("Candara",1,18));
        adminrec.setBackground(Color.WHITE);
        adminrec.setForeground(Color.BLACK);
        add(adminrec);
        adminrec.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                try {
                    new AdminRecords().setVisible(true);
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        JButton packagedetails=new JButton("PACKAGE UPDATES");
        packagedetails.setBounds(50,280,200,35);
        packagedetails.setFont(new Font("Candara",1,18));
        packagedetails.setBackground(Color.WHITE);
        packagedetails.setForeground(Color.BLACK);
        add(packagedetails);
        packagedetails.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                try {
                    new ManagerPackageUpdate().setVisible(true);
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        JButton hoteldetails=new JButton("HOTEL UPDATES");
        hoteldetails.setBounds(50,340,200,35);
        hoteldetails.setFont(new Font("Candara",1,18));
        hoteldetails.setBackground(Color.WHITE);
        hoteldetails.setForeground(Color.BLACK);
        add(hoteldetails);
        hoteldetails.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                try {
                    new ManagerHotelUpdate().setVisible(true);
                } catch (Exception ex) {
                    throw new RuntimeException(ex);
                }
            }
        });

        JButton close=new JButton("CLOSE");
        close.setBounds(50,400,200,35);
        close.setFont(new Font("Candara",1,18));
        close.setBackground(Color.WHITE);
        close.setForeground(Color.BLACK);
        add(close);
        close.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                JOptionPane.showMessageDialog(null,"HAVE A NICE DAY....!");
                System.exit(0);
            }
        });
        setVisible(true);
    }
    public static void main(String ...s)
    {
        new ManagerHotelUpdate().setVisible(true);
    }
}
