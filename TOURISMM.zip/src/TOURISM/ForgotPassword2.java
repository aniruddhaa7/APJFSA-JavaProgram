package TOURISM;
import java.awt.*;
import javax.swing.*;
import javax.swing.border.*;
import java.sql.*;
import java.awt.event.*;

public class ForgotPassword2 extends JFrame implements ActionListener{

    private JPanel contentPane;
    private JTextField t1,t2,t3,t4,t5;
    private JButton b1,b2,b3;

    public static void main(String[] args)
    {
        new ForgotPassword2("","","","").setVisible(true);
    }

    public ForgotPassword2(String username,String name,String question,String answer) {

        setBounds(230, 80, 850, 450);
        contentPane = new JPanel();
        contentPane.setBorder(new LineBorder(new Color(128, 128, 0), 2));
        setContentPane(contentPane);
        contentPane.setBackground(new Color(248, 36, 36, 255));
        contentPane.setLayout(null);

        JLabel l1 = new JLabel("Username :");
        l1.setForeground(Color.WHITE);
        l1.setFont(new Font("Segoe UI", 1, 18));
        l1.setBounds(40, 83, 100, 29);
        contentPane.add(l1);

        JLabel l2 = new JLabel("Name :");
        l2.setBounds(40, 122, 75, 21);
        l2.setForeground(Color.WHITE);
        l2.setFont(new Font("Segoe UI", 1, 18));
        contentPane.add(l2);

        JLabel l3 = new JLabel("Your Security Question:");
        l3.setBounds(40, 154, 200, 27);
        l3.setForeground(Color.WHITE);
        l3.setFont(new Font("Segoe UI", 1, 18));
        contentPane.add(l3);

        JLabel l4 = new JLabel("Answer :");
        l4.setBounds(40, 192, 104, 21);
        l4.setForeground(Color.WHITE);
        l4.setFont(new Font("Segoe UI", 1, 18));
        contentPane.add(l4);

        JLabel l5 = new JLabel("Password :");
        l5.setFont(new Font("Tahoma", Font.BOLD, 13));
        l5.setForeground(Color.WHITE);
        l5.setFont(new Font("Segoe UI", 1, 18));
        l5.setBounds(40, 224, 104, 21);
        contentPane.add(l5);

        t1 = new JTextField(username);
        t1.setEditable(false);
        t1.setFont(new Font("Tahoma", Font.BOLD, 13));
        t1.setForeground(new Color(80, 32, 32));
        t1.setBounds(250, 88, 221, 20);
        contentPane.add(t1);
        t1.setColumns(10);

        t2 = new JTextField(name);
        t2.setEditable(false);
        t2.setFont(new Font("Tahoma", Font.BOLD, 13));
        t2.setForeground(new Color(80, 32, 32));
        t2.setColumns(10);
        t2.setBounds(250, 123, 221, 20);
        contentPane.add(t2);

        t3 = new JTextField(question);
        t3.setEditable(false);
        t3.setFont(new Font("Tahoma", Font.BOLD, 12));
        t3.setForeground(new Color(80, 32, 32));
        t3.setColumns(10);
        t3.setBounds(250, 161, 221, 20);
        contentPane.add(t3);

        t4 = new JTextField(answer);
        t4.setEditable(false);
        t4.setFont(new Font("Tahoma", Font.BOLD, 13));
        t4.setForeground(new Color(80, 32, 32));
        t4.setColumns(10);
        t4.setBounds(250, 193, 221, 20);
        contentPane.add(t4);

        t5 = new JTextField();
        t5.setFont(new Font("Tahoma", Font.BOLD, 13));
        t5.setForeground(new Color(80, 32, 32));
        t5.setColumns(10);
        t5.setBounds(250, 225, 139, 20);
        contentPane.add(t5);

        ImageIcon c1 = new ImageIcon(ClassLoader.getSystemResource("icons/forgetpassword1.png"));
        Image i1 = c1.getImage().getScaledInstance(300, 300,Image.SCALE_DEFAULT);
        ImageIcon i2 = new ImageIcon(i1);
        JLabel l6 = new JLabel(i2);
        l6.setBounds(520, 70, 300, 300);
        add(l6);

        b1 = new JButton("Search");
        b1.addActionListener(this);
        //b1.setFont(new Font("Tahoma", Font.BOLD, 12));
        b1.setFont(new Font("Segoe UI", 1, 16));
        b1.setBounds(410, 83, 100, 29);
        b1.setBackground(new Color(80, 32, 32));
        b1.setForeground(Color.WHITE);
        //contentPane.add(b1);

        b2 = new JButton("UPDATE");
        b2.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Conn con=new Conn();
                String sql = "select * from account where answer='"+t4.getText()+"' AND username='"+t1.getText()+"' AND question='"+t3.getText()+"'";
                ResultSet rs = null;
                try {
                    rs = con.s.executeQuery(sql);
                    if(rs.next())
                    {
                        con.s.executeUpdate("update account set password=md5('"+t5.getText()+"')");
                        JOptionPane.showMessageDialog(null,"PASSWORD UPDATED SUCCESSFULLY");
                        setVisible(false);
                        new Login().setVisible(true);
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(null,"WRONG ANSWER");
                    }
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });
        b2.setFont(new Font("Segoe UI", 1, 16));
        b2.setBounds(410, 225, 100, 29);
        b2.setBackground(new Color(80, 32, 32));
        b2.setForeground(Color.WHITE);
        contentPane.add(b2);

        b3 = new JButton("Back");
        b3.addActionListener(this);
        b3.setFont(new Font("Segoe UI", 1, 16));
        b3.setBounds(233, 270, 101, 29);
        b3.setBackground(new Color(80, 32, 32));
        b3.setForeground(Color.WHITE);
        contentPane.add(b3);

        JPanel panel = new JPanel();
        panel.setBounds(47, 45, 508, 281);
        panel.setBackground(new Color(248, 36, 36, 255));
        contentPane.add(panel);
    }

    public void actionPerformed(ActionEvent ae){
        try{
            Conn con = new Conn();
            if(ae.getSource() == b3){
                this.setVisible(false);
                new Login().setVisible(true);

            }
        }catch(Exception e){

        }
    }

}
