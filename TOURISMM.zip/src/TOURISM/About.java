package TOURISM;

import java.awt.*;
import java.awt.event.*;

import javax.swing.*;

import java.awt.Font;
import javax.swing.JFrame;
import javax.swing.border.Border;

public class About extends JFrame implements ActionListener {

    JButton b1;
    JLabel l1;
    Font f, f1, f2;
    TextArea t1;
    String s;

    public About() {

        setLayout(null);
        JButton b1 = new JButton("CLOSE");
        b1.setBackground(new Color(0,0,0));
        b1.setForeground(new Color(255, 255, 255));
        add(b1);
        b1.setBounds(180, 440, 120, 20);
        b1.addActionListener(this);

        Font f = new Font("RALEWAY", Font.BOLD, 180);
        setFont(f);

        s = "                                    ABOUT US          \n  "
        +"Travel and tourism management system is used to book a tour from anywhere in"
        +"the world by a single dynamic website which will help the user to know all"
        +"about the places and tour details in a single website." +
        " The admin can add packages to the website from a certain travel agents and hotels so the same"
        +"interface is provided which is made with swing, ImageIcon is used to add"
        +"wallpaper to frame, JLabel, JMenuBar, etc are used in admin interface. " +
        "Then the users can sign in and book package they want to book. The user can see the"
        +"check package, hotel they have booked. " +
        "It is a easiest platform for all travellers which can be easily booked and know the all details." +
        " Tour Management system is a dynamic website for tourism business. It is dynamic and responsive web"
        +"design. We can say travel technology solution for agencies & tour operation."
        +"Nearly Everyone goes on a vacation for this ‘a Tourism management"
        +"system’ would play a vital role in planning the perfect trip. The tourism"
        +"management system allows the user of the system access all the details such is"
        +"location, events, etc. and transport, hotel facilities is also provided which is"
        +"optional if user want both or one of them the charges will reflect in details. The"
        +"main purpose is to help tourism companies to manage customer and hotels, etc"
        ;

        TextArea t1 = new TextArea(s, 10, 40,Scrollbar.VERTICAL);
        t1.setEditable(false);
        t1.setBounds(20, 100, 500, 300);
        add(t1);

        Font f1 = new Font("Candara", 1, 16);
        t1.setFont(f1);

        Container contentPane = this.getContentPane();
        t1 = new TextArea();

        JLabel l1 = new JLabel("ABOUT US");
        add(l1);
        l1.setBounds(220, 10, 180, 80);
        l1.setForeground(new Color(12, 149, 208));

        Font f2 = new Font("RALEWAY", Font.BOLD, 20);
        l1.setFont(f2);

        setBounds(350, 100, 550, 550);

        setLayout(null);
        setVisible(true);

    }

    public void actionPerformed(ActionEvent e) {
        dispose();
    }

    public static void main(String args[]) {
        new About().setVisible(true);
    }

}
