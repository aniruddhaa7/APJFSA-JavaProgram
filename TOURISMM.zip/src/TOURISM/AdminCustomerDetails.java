package TOURISM;
import java.awt.*;
import java.awt.BorderLayout;
import java.awt.EventQueue;
import javax.swing.border.EmptyBorder;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.sql.*;
import javax.swing.*;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.time.LocalDate;

public class AdminCustomerDetails extends JFrame {
    private JPanel content;
    String usernm;
    int head=30;
    int width=320;
    int info=160;
    int head2=580;
    int info2=770;

    public static void main(String[] args) {
        EventQueue.invokeLater(new Runnable() {
            public void run() {
                try
                {
                    AdminCustomerDetails frame = new AdminCustomerDetails();
                    frame.setVisible(true);
                }
                catch (Exception e)
                {
                    e.printStackTrace();
                }
            }
        });
    }

    public AdminCustomerDetails() throws SQLException {
        setBounds(90, 70, 1100, 520);
        content = new JPanel();
        setContentPane(content);
        getContentPane().setBackground(new Color(0, 252, 211));
        content.setLayout(null);

        JLabel l1 = new JLabel("Search name: ");
        l1.setFont(new Font("Candara", 1, 22));
        l1.setBounds(30, 35, 150, 25);
        content.add(l1);

        JLabel l2 = new JLabel("USERNAME:");
        l2.setBounds(head, 90, 150, 25);
        l2.setFont(new Font("Candara",1,22));
        content.add(l2);

        JLabel l2a = new JLabel();
        l2a.setBounds(info, 90, width, 25);
        l2a.setFont(new Font("Candara",1,22));
        content.add(l2a);

        JLabel lblid = new JLabel("ID:");
        lblid.setBounds(head, 120, 80, 25);
        lblid.setFont(new Font("Candara",1,22));
        add(lblid);

        JLabel aid = new JLabel();
        aid.setBounds(info, 120, 150, 25);
        aid.setFont(new Font("Candara",1,22));
        add(aid);

        JLabel lblnumber = new JLabel("NUMBER:");
        lblnumber.setBounds(head, 150, 150, 25);
        lblnumber.setFont(new Font("Candara",1,22));
        add(lblnumber);

        JLabel anum = new JLabel();
        anum.setBounds(info, 150, 150, 25);
        anum.setFont(new Font("Candara",1,22));
        add(anum);

        JLabel lblname = new JLabel("NAME:");
        lblname.setBounds(head, 180, 150, 25);
        lblname.setFont(new Font("Candara",1,22));
        add(lblname);

        JLabel aname = new JLabel();
        aname.setBounds(info, 180, width, 25);
        aname.setFont(new Font("Candara",1,22));
        add(aname);

        JLabel lblgender = new JLabel("GENDER:");
        lblgender.setBounds(head, 210, 150, 25);
        lblgender.setFont(new Font("Candara",1,22));
        add(lblgender);

        JLabel agender = new JLabel();
        agender.setBounds(info, 210, 150, 25);
        agender.setFont(new Font("Candara",1,22));
        add(agender);

        JLabel lblcountry = new JLabel("COUNTRY:");
        lblcountry.setBounds(head, 240, 150, 25);
        lblcountry.setFont(new Font("Candara",1,22));
        add(lblcountry);

        JLabel acountry = new JLabel();
        acountry.setBounds(info, 240, width, 25);
        acountry.setFont(new Font("Candara",1,22));
        add(acountry);

        JLabel lbladdress = new JLabel("ADDRESS:");
        lbladdress.setBounds(head, 270, 150, 25);
        lbladdress.setFont(new Font("Candara",1,22));
        add(lbladdress);

        JLabel aaddress = new JLabel();
        aaddress.setBounds(info, 270, width, 25);
        aaddress.setFont(new Font("Candara",1,22));
        add(aaddress);

        JLabel lblphone = new JLabel("PHONE:");
        lblphone.setBounds(head, 300, 150, 25);
        lblphone.setFont(new Font("Candara",1,22));
        add(lblphone);

        JLabel aphone = new JLabel();
        aphone.setBounds(info, 300, 150, 25);
        aphone.setFont(new Font("Candara",1,22));
        add(aphone);

        JLabel lblemail = new JLabel("EMAIL:");
        lblemail.setBounds(head, 330, 80, 25);
        lblemail.setFont(new Font("Candara",1,22));
        add(lblemail);

        JLabel aemail = new JLabel();
        aemail.setBounds(info, 330, width, 25);
        aemail.setFont(new Font("Candara",1,22));
        add(aemail);

        JLabel l3 = new JLabel("PACKAGE:");
        l3.setBounds(head2, 90, 180, 25);
        l3.setFont(new Font("Candara",1,22));
        content.add(l3);

        JLabel l3a = new JLabel();
        l3a.setBounds(info2, 90, width, 25);
        l3a.setFont(new Font("Candara",1,22));
        content.add(l3a);

        JLabel l4 = new JLabel("NO_OF_PERSONS:");
        l4.setBounds(head2, 120, 180, 25);
        l4.setFont(new Font("Candara",1,22));
        add(l4);

        JLabel l4a = new JLabel();
        l4a.setBounds(info2, 120, 150, 25);
        l4a.setFont(new Font("Candara",1,22));
        add(l4a);

        JLabel l5 = new JLabel("TRANSPORT:");
        l5.setBounds(head2, 150, 150, 25);
        l5.setFont(new Font("Candara",1,22));
        add(l5);

        JLabel l5a = new JLabel();
        l5a.setBounds(info2, 150, width, 25);
        l5a.setFont(new Font("Candara",1,22));
        add(l5a);

        JLabel l6 = new JLabel("PACKAGE PRICE:");
        l6.setBounds(head2, 180, 190, 25);
        l6.setFont(new Font("Candara",1,22));
        add(l6);

        JLabel l6a = new JLabel();
        l6a.setBounds(info2, 180, 150, 25);
        l6a.setFont(new Font("Candara",1,22));
        add(l6a);

        JLabel l7 = new JLabel("HOTEL NAME:");
        l7.setBounds(head2, 210, 190, 25);
        l7.setFont(new Font("Candara",1,22));
        add(l7);

        JLabel l7a = new JLabel();
        l7a.setBounds(info2, 210, width, 25);
        l7a.setFont(new Font("Candara",1,22));
        add(l7a);

        JLabel l8 = new JLabel("NO_OF_PERSON:");
        l8.setBounds(head2, 240, 180, 25);
        l8.setFont(new Font("Candara",1,22));
        add(l8);

        JLabel l8a = new JLabel();
        l8a.setBounds(info2, 240, 150, 25);
        l8a.setFont(new Font("Candara",1,22));
        add(l8a);

        JLabel l9 = new JLabel("DAYS:");
        l9.setBounds(head2, 270, 80, 25);
        l9.setFont(new Font("Candara",1,22));
        add(l9);

        JLabel l9a = new JLabel();
        l9a.setBounds(info2, 270, 150, 25);
        l9a.setFont(new Font("Candara",1,22));
        add(l9a);

        JLabel l10 = new JLabel("AC:");
        l10.setBounds(head2, 300, 80, 25);
        l10.setFont(new Font("Candara",1,22));
        add(l10);

        JLabel l10a = new JLabel();
        l10a.setBounds(info2, 300, 150, 25);
        l10a.setFont(new Font("Candara",1,22));
        add(l10a);

        JLabel l11 = new JLabel("FOOD:");
        l11.setBounds(head2, 330, 80, 25);
        l11.setFont(new Font("Candara",1,22));
        add(l11);

        JLabel l11a = new JLabel();
        l11a.setBounds(info2, 330, 150, 25);
        l11a.setFont(new Font("Candara",1,22));
        add(l11a);

        JLabel l12 = new JLabel("HOTEL COST:");
        l12.setBounds(head2, 360, 150, 25);
        l12.setFont(new Font("Candara",1,22));
        content.add(l12);

        JLabel l12a = new JLabel();
        l12a.setBounds(info2, 360, 150, 25);
        l12a.setFont(new Font("Candara",1,22));
        content.add(l12a);

        JLabel l13 = new JLabel("TOTAL COST:");
        l13.setBounds(200, 420, 150, 25);
        l13.setFont(new Font("Candara",1,22));
        content.add(l13);

        JLabel l13a = new JLabel();
        l13a.setBounds(340, 420, 150, 25);
        l13a.setFont(new Font("Candara",1,22));
        content.add(l13a);

        Choice c1 = new Choice();
        Conn c = new Conn();
        try
        {
            ResultSet rs = c.s.executeQuery("select * from account where Payment_Status='PENDING' order by name asc");
            while (rs.next()) {
                c1.add(rs.getString("name"));
            }
            rs.close();
        } catch (SQLException e) {
        }
        c1.setBounds(180, 35, 300, 30);
        c1.addItemListener(new ItemListener() {
            @Override
            public void itemStateChanged(ItemEvent e) {
                Conn c = new Conn();
                try {
                    int cost = 0;
                    int price = 0;
                    int pricee=0;
                    ResultSet rs = c.s.executeQuery("select * from customer where name='" + c1.getSelectedItem() + "'");
                    while (rs.next()) {
                        l2a.setText(rs.getString("username"));
                        usernm = rs.getString("username");
                        aid.setText(rs.getString("id_type"));
                        aname.setText(rs.getString("name"));
                        anum.setText(rs.getString("number"));
                        agender.setText(rs.getString("gender"));
                        acountry.setText(rs.getString("country"));
                        aaddress.setText(rs.getString("address"));
                        aphone.setText(rs.getString("phone"));
                        aemail.setText(rs.getString("email"));
                    }
                    rs = c.s.executeQuery("select * from bookpackage where username='" + usernm + "'");
                    if (rs.next()) {
                        l3a.setText(rs.getString("selected"));
                        l4a.setText(rs.getString("person"));
                        l5a.setText(rs.getString("currentp"));
                        l6a.setText(rs.getString("cost"));
                        price = Integer.parseInt(rs.getString("cost"));
                    }
                    cost += price;
                    rs = c.s.executeQuery("select * from bookhotel where username='" + usernm + "'");
                    if (rs.next()) {
                        l7a.setText(rs.getString("name"));
                        l8a.setText(rs.getString("persons"));
                        l9a.setText(rs.getString("days"));
                        l10a.setText(rs.getString("ac"));
                        l11a.setText(rs.getString("food"));
                        l12a.setText(rs.getString("price"));
                        price = Integer.parseInt(rs.getString("price"));
                    }
                    cost += price;
                    l13a.setText("" + cost);
                    //rs.close();
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }
            }
        });
        add(c1);

        JButton b0 = new JButton("Delete");
        b0.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Conn c = new Conn();
                try{
                    String s1 = c1.getSelectedItem();
                    ResultSet rs=c.s.executeQuery("select * from account where name='"+s1+"'");
                    String user=rs.getString(1);
                    c.s.executeUpdate("delete from customer where username = '"+user+"'");
                    c.s.executeUpdate("delete from bookpackage where username='"+user+"'");
                    c.s.executeUpdate("delete from bookhotel where username='"+user+"'");
                    c.s.executeUpdate("delete from account where username='"+user+"'");
                    JOptionPane.showMessageDialog(null, "Customer Detail Deleted Successfully");
                    //setVisible(false);
                }catch(SQLException e1){
                    System.out.println(e1.getMessage());
                }
                catch(NumberFormatException s){
                    JOptionPane.showMessageDialog(null, "Please enter a valid Number");
                }
            }
        });
        b0.setBounds(490, 35, 100, 25);
        b0.setBackground(Color.BLACK);
        b0.setForeground(Color.YELLOW);
        //content.add(b0);

        JButton b2 = new JButton("Reset");
        b2.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                l2a.setText("NONE");
                aid.setText("NONE");
                aname.setText("NONE");
                anum.setText("NONE");
                agender.setText("NONE");
                acountry.setText("NONE");
                aaddress.setText("NONE");
                aphone.setText("NONE");
                aemail.setText("NONE");
                l3a.setText("NONE");
                l4a.setText("NONE");
                l5a.setText("NONE");
                l6a.setText("NONE");
                l7a.setText("NONE");
                l8a.setText("NONE");
                l9a.setText("NONE");
                l10a.setText("NONE");
                l11a.setText("NONE");
                l12a.setText("NONE");
                l13a.setText("NONE");
            }
        });
        b2.setBounds(600, 35, 100, 25);
        b2.setBackground(Color.BLACK);
        b2.setForeground(Color.YELLOW);
        content.add(b2);

        JButton b3 = new JButton("Reset ALL");
        b3.addActionListener(new ActionListener() {
            public void actionPerformed(ActionEvent e) {
                Conn c=new Conn();
                String s1 = c1.getSelectedItem();
                ResultSet rs= null;
                try {
                    rs = c.s.executeQuery("select * from account where name='"+s1+"'");
                    String user = null;
                    if(rs.next())
                    {
                        user=rs.getString(1);
                    }
                    rs=c.s.executeQuery("select * from bookpackage where username='"+user+"'");
                    if(rs.next())
                    {
                        if(rs.getString(2).equals("NONE"))
                        {
                            JOptionPane.showMessageDialog(null,"PACKAGE ALREADY USUAL");
                            return;
                            //c.s.executeUpdate("delete from bookpackage where username='" + username + "'");
                        }
                        else
                        {
                                c.s.executeUpdate("delete from bookpackage where username='" + user + "'");
                                c.s.executeUpdate("delete from bookhotel where username='" + user + "'");
                                c.s.executeUpdate("insert into bookpackage values('"+user+"', 'NONE', 0, 'NONE', 'NONE', 'NONE', '0','NONE','2001/12/12')");
                                c.s.executeUpdate("insert into bookhotel values('"+user+"', 'NONE', '0', '0', 'NONE', 'NONE', 'NONE','0','0','0','2001/12/12')");
                                JOptionPane.showMessageDialog(null,"PACKAGE IS NULL NOW");
                        }
                    }
                } catch (SQLException ex) {
                    throw new RuntimeException(ex);
                }

            }
        });
        b3.setBounds(710, 35, 130, 25);
        b3.setBackground(Color.BLACK);
        b3.setForeground(Color.YELLOW);
        content.add(b3);

        JButton payment=new JButton("PAYMENT  RECEIVED");
        payment.setBounds(850, 35, 170, 25);
        payment.setBackground(Color.BLACK);
        payment.setForeground(Color.YELLOW);
        payment.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                Conn c=new Conn();
                try
                {
                    ResultSet rs=c.s.executeQuery("select * from bookpackage where username='"+l2a.getText()+"'");
                    while(rs.next())
                    {
                        if(rs.getString(2).equals("NONE"))
                        {
                            JOptionPane.showMessageDialog(null,"PACKAGE NOT BOOKED");
                            return;
                        }
                    }
                    rs=c.s.executeQuery("select * from account where username='"+l2a.getText()+"'");
                    if(rs.next())
                    {
                        if(rs.getString(6).equals("PENDING"))
                        {
                            String date=String.valueOf(LocalDate.now());
                            c.s.executeUpdate("update account set Payment_Status='DONE',Date='"+date+"' where username='"+l2a.getText()+"'");
                            JOptionPane.showMessageDialog(null,"RECEIVED PAYMENT OF RS."+l13a.getText()+" TICKET IS GENERATED..!");
                            setVisible(false);
                            setVisible(true);
                        }
                        else
                        {
                            JOptionPane.showMessageDialog(null,"ALREADY SAVED");
                            return;
                        }
                    }
                }
                catch(Exception ex){}
            }
        });
        content.add(payment);
    }
}
