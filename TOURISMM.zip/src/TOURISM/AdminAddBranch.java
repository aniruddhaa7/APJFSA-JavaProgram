package TOURISM;
import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.sql.ResultSet;
import java.sql.SQLException;

public class AdminAddBranch extends JFrame
{
    public static void main (String ...s)
    {
        new AdminAddBranch().setVisible(true);
    }
    JButton change;

    public AdminAddBranch()
    {
        setBounds(300,80,700,550);

        JPanel p=new JPanel();
        p.setBackground(Color.WHITE);
        p.setLayout(null);
        add(p);

        JLabel l1=new JLabel("Add Branch Details");
        l1.setFont(new Font("Yu Mincho", Font.BOLD, 25));
        l1.setBounds(230,20,250,25);
        p.add(l1);

        JLabel l2=new JLabel("Enter City: ");
        l2.setFont(new Font("Yu Mincho",Font.BOLD,20));
        l2.setBounds(80,70,120,25);
        p.add(l2);

        JLabel l3=new JLabel("Address: ");
        l3.setFont(new Font("Yu Mincho",Font.BOLD,20));
        l3.setBounds(80,150,120,25);
        p.add(l3);

        JLabel l4=new JLabel("Town: ");
        l4.setFont(new Font("Yu Mincho",Font.BOLD,20));
        l4.setBounds(80,200,120,25);
        p.add(l4);

        JLabel l5=new JLabel("Area: ");
        l5.setFont(new Font("Yu Mincho",Font.BOLD,20));
        l5.setBounds(80,250,120,25);
        p.add(l5);

        JLabel l6=new JLabel("Pincode: ");
        l6.setFont(new Font("Yu Mincho",Font.BOLD,20));
        l6.setBounds(80,300,120,25);
        p.add(l6);

        JLabel l7=new JLabel("Phone: ");
        l7.setFont(new Font("Yu Mincho",Font.BOLD,20));
        l7.setBounds(80,350,120,25);
        p.add(l7);

        JLabel l11=new JLabel("Choose:");
        l11.setFont(new Font("Yu Mincho",Font.BOLD,20));
        l11.setBounds(80,110,120,25);
        p.add(l11);

        JTextField t1=new JTextField();
        t1.setBounds(200,72,250,25);
        p.add(t1);

        JTextField address=new JTextField();
        address.setBounds(200,154,380,25);
        p.add(address);

        JTextField town=new JTextField();
        town.setBounds(200,204,380,25);
        p.add(town);

        JTextField area=new JTextField();
        area.setBounds(200,254,380,25);
        p.add(area);

        JTextField pin=new JTextField();
        pin.setBounds(200,304,380,25);
        p.add(pin);

        JTextField phone=new JTextField();
        phone.setBounds(200,354,380,25);
        p.add(phone);

        Choice c9=new Choice();
        Conn c=new Conn();
        try
        {
            ResultSet rs = c.s.executeQuery("select * from locations");
            while (rs.next())
            {
                c9.add(rs.getString(1));
            }
            rs.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        c9.setBounds(200,112,250,60);
        p.add(c9);

        JButton add=new JButton("ADD");
        add.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e) {
                Conn c = new Conn();
                try
                {
                    ResultSet rs=c.s.executeQuery("select * from locations");
                    while(rs.next())
                    {
                        if(t1.getText().equals(rs.getString(1)))
                        {
                            JOptionPane.showMessageDialog(null,"Already present");
                            return;
                        }
                    }
                    c.s.executeUpdate("insert into locations values('"+t1.getText()+"','NONE','NONE','NONE','NONE','NONE')");
                    c9.add(t1.getText());
                    JOptionPane.showMessageDialog(null,"Added Successfully");
                } catch (SQLException e1) {
                    throw new RuntimeException(e1);
                }
            }
        });
        add.setBounds(470,72,100,25);
        p.add(add);

        JButton save=new JButton("SAVE");
        save.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e) {
                Conn c = new Conn();
                try
                {
                    c.s.executeUpdate("update locations set address='"+address.getText()+"',cityortown='"+town.getText()+"',area='"+area.getText()+"',pincode='"+pin.getText()+"',phone='"+phone.getText()+"' where currentplace='"+c9.getSelectedItem()+"'");
                    c9.add(t1.getText());
                    JOptionPane.showMessageDialog(null,"Added Successfully");
                    setVisible(false);
                } catch (SQLException e1) {
                    throw new RuntimeException(e1);
                }
            }
        });
        save.setBounds(180,420,100,25);
        p.add(save);

        JButton back=new JButton("BACK");
        back.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e) {
                Conn c = new Conn();
                {
                    setVisible(false);
                }
            }
        });
        back.setBounds(390,420,100,25);
        p.add(back);

        change = new JButton("CLICK FOR EDIT BRANCH");
        change.setForeground(Color.WHITE);
        change.setFont(new Font("Segoe UI",0,18));
        change.setBackground(new Color(12, 11, 11));
        change.setBounds(210, 460, 250, 35);
        change.addActionListener(new ActionListener() {
            @Override
            public void actionPerformed(ActionEvent e) {
                setVisible(false);
                new AdminEditBranch().setVisible(true);
            }
        });
        p.add(change);
    }
}