package TOURISM;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.sql.*;
import java.sql.ResultSet;
public class AdminTransport extends JFrame
{
    public static void main(String[] args)
    {
        new AdminTransport().setVisible(true);
    }
    AdminTransport()
    {
        setBounds(200,80,900,550);

        JPanel p=new JPanel();
        p.setBackground(Color.WHITE);
        p.setLayout(null);
        add(p);

        JLabel l1=new JLabel("Transport Details");
        l1.setFont(new Font("Yu Mincho", Font.BOLD, 25));
        l1.setBounds(350,20,250,25);
        p.add(l1);

        JLabel l2=new JLabel("Enter City: ");
        l2.setFont(new Font("Yu Mincho",Font.BOLD,20));
        l2.setBounds(80,70,120,25);
        p.add(l2);

        JTextField t1=new JTextField();
        t1.setBounds(200,72,250,25);
        p.add(t1);

        JTextField t2=new JTextField();
        t2.setBounds(540,235,170,22);
        p.add(t2);

        JTextField t3=new JTextField();
        t3.setBounds(540,295,170,22);
        p.add(t3);

        JLabel l3=new JLabel("Show Info: ");
        l3.setFont(new Font("Yu Mincho",Font.BOLD,20));
        l3.setBounds(80,170,120,25);
        p.add(l3);

        JLabel l4=new JLabel("Add Info: ");
        l4.setFont(new Font("Yu Mincho",Font.BOLD,20));
        l4.setBounds(80,230,120,25);
        p.add(l4);

        JLabel l5=new JLabel("Edit Info: ");
        l5.setFont(new Font("Yu Mincho",Font.BOLD,20));
        l5.setBounds(80,290,120,25);
        p.add(l5);

        JLabel l6=new JLabel("Delete Info: ");
        l6.setFont(new Font("Yu Mincho",Font.BOLD,20));
        l6.setBounds(80,350,120,25);
        p.add(l6);

        JLabel l7=new JLabel("FROM");
        l7.setFont(new Font("Yu Mincho",Font.BOLD,20));
        l7.setBounds(240,140,120,25);
        p.add(l7);

        JLabel l8=new JLabel("TO");
        l8.setFont(new Font("Yu Mincho",Font.BOLD,20));
        l8.setBounds(420,140,120,25);
        p.add(l8);

        JLabel l9=new JLabel("COST");
        l9.setFont(new Font("Yu Mincho",Font.BOLD,20));
        l9.setBounds(560,140,120,25);
        p.add(l9);

        JLabel l10=new JLabel();
        l10.setFont(new Font("Yu Mincho",Font.BOLD,15));
        l10.setBounds(540,170,120,25);
        p.add(l10);

        JLabel l11=new JLabel("Choose:");
        l11.setFont(new Font("Yu Mincho",Font.BOLD,20));
        l11.setBounds(80,110,120,25);
        p.add(l11);

        Choice c1=new Choice();
        Conn c=new Conn();
        try
        {
            ResultSet rs = c.s.executeQuery("select * from locations");
            while (rs.next())
            {
                if(rs.getString(1).equals("NONE"))
                {
                    continue;
                }
                else
                {
                    c1.add(rs.getString(1));
                }
            }
            rs.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        c1.setBounds(200,174,160,60);
        p.add(c1);

        Choice c2=new Choice();
        c=new Conn();
        try
        {
            ResultSet rs = c.s.executeQuery("select * from locations");
            while (rs.next())
            {
                if(rs.getString(1).equals("NONE"))
                {
                    continue;
                }
                else
                {
                    c2.add(rs.getString(1));
                }
            }
            rs.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        c2.setBounds(370,174,160,60);
        p.add(c2);

        Choice c3=new Choice();
        c=new Conn();
        try
        {
            ResultSet rs = c.s.executeQuery("select * from locations");
            while (rs.next())
            {
                if(rs.getString(1).equals("NONE"))
                {
                    continue;
                }
                else
                {
                    c3.add(rs.getString(1));
                }
            }
            rs.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        c3.setBounds(200,234,160,60);
        p.add(c3);

        Choice c4=new Choice();
        c=new Conn();
        try
        {
            ResultSet rs = c.s.executeQuery("select * from locations");
            while (rs.next())
            {
                if(rs.getString(1).equals("NONE"))
                {
                    continue;
                }
                else
                {
                    c4.add(rs.getString(1));
                }
            }
            rs.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        c4.setBounds(370,234,160,60);
        p.add(c4);

        Choice c5=new Choice();
        c=new Conn();
        try
        {
            ResultSet rs = c.s.executeQuery("select * from locations");
            while (rs.next())
            {
                if(rs.getString(1).equals("NONE"))
                {
                    continue;
                }
                else
                {
                    c5.add(rs.getString(1));
                }
            }
            rs.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        c5.setBounds(200,294,160,60);
        p.add(c5);

        Choice c6=new Choice();
        c=new Conn();
        try
        {
            ResultSet rs = c.s.executeQuery("select * from locations");
            while (rs.next())
            {
                if(rs.getString(1).equals("NONE"))
                {
                    continue;
                }
                else
                {
                    c6.add(rs.getString(1));
                }
            }
            rs.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        c6.setBounds(370,294,160,60);
        p.add(c6);

        Choice c7=new Choice();
        c=new Conn();
        try
        {
            ResultSet rs = c.s.executeQuery("select * from locations");
            while (rs.next())
            {
                if(rs.getString(1).equals("NONE"))
                {
                    continue;
                }
                else
                {
                    c7.add(rs.getString(1));
                }
            }
            rs.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        c7.setBounds(200,354,160,60);
        p.add(c7);

        Choice c8=new Choice();
        c=new Conn();
        try
        {
            ResultSet rs = c.s.executeQuery("select * from locations");
            while (rs.next())
            {
                if(rs.getString(1).equals("NONE"))
                {
                    continue;
                }
                else
                {
                    c8.add(rs.getString(1));
                }
            }
            rs.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        c8.setBounds(370,354,160,60);
        p.add(c8);

        Choice c9=new Choice();
        c=new Conn();
        try
        {
            ResultSet rs = c.s.executeQuery("select * from locations");
            while (rs.next())
            {
                if(rs.getString(1).equals("NONE"))
                {
                    continue;
                }
                else
                {
                    c9.add(rs.getString(1));
                }
            }
            rs.close();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        c9.setBounds(200,112,250,60);
        p.add(c9);

        JButton add=new JButton("ADD");
        add.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e) {
                Conn c = new Conn();
                try
                {
                    ResultSet rs=c.s.executeQuery("select * from locations");
                    while(rs.next())
                    {
                        if(t1.getText().equals(rs.getString(1)))
                        {
                            JOptionPane.showMessageDialog(null,"Already present");
                            return;
                        }
                    }
                    c.s.executeUpdate("insert into locations values('"+t1.getText()+"','NONE','NONE','NONE','NONE','NONE')");
                    c1.add(t1.getText());
                    c2.add(t1.getText());
                    c3.add(t1.getText());
                    c4.add(t1.getText());
                    c5.add(t1.getText());
                    c6.add(t1.getText());
                    c7.add(t1.getText());
                    c8.add(t1.getText());
                    c9.add(t1.getText());
                    JOptionPane.showMessageDialog(null,"Added Successfully");
                } catch (SQLException e1) {
                    throw new RuntimeException(e1);
                }
            }
        });
        add.setBounds(470,72,100,25);
        p.add(add);

        JButton remove=new JButton("REMOVE");
        remove.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e) {
                Conn c = new Conn();
                try
                {
                    c.s.executeUpdate("delete from locations where currentplace='"+c9.getSelectedItem()+"'");
                    c1.remove(c9.getSelectedItem());
                    c2.remove(c9.getSelectedItem());
                    c3.remove(c9.getSelectedItem());
                    c4.remove(c9.getSelectedItem());
                    c5.remove(c9.getSelectedItem());
                    c6.remove(c9.getSelectedItem());
                    c7.remove(c9.getSelectedItem());
                    c8.remove(c9.getSelectedItem());
                    c9.remove(c9.getSelectedItem());
                    JOptionPane.showMessageDialog(null,"Removed Successfully");
                } catch (SQLException e1) {
                    throw new RuntimeException(e1);
                }
            }
        });
        remove.setBounds(470,112,100,25);
        p.add(remove);

        JButton b2=new JButton("SHOW");
        b2.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e) {
                l10.setText("");
                Conn c = new Conn();
                try
                {
                    if(c1.getSelectedItem().equals(c2.getSelectedItem()))
                    {
                        JOptionPane.showMessageDialog(null,"INVALID ENTRY");
                        return;
                    }
                    ResultSet rs = c.s.executeQuery("select * from transport where distance='" + c1.getSelectedItem() + "-" + c2.getSelectedItem() + "'");
                    if (rs.next())
                    {
                        l10.setText(rs.getString(2));
                    }
                    else
                    {
                        JOptionPane.showMessageDialog(null,"ITS MISSING");
                        return;
                    }
                    rs.close();
                } catch (SQLException e1) {
                    throw new RuntimeException(e1);
                }
            }
        });
        b2.setBounds(720,170,100,25);
        p.add(b2);

        JButton b3=new JButton("SAVE");
        b3.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e) {
                Conn c = new Conn();
                try
                {
                    if(c3.getSelectedItem().equals(c4.getSelectedItem()))
                    {
                        JOptionPane.showMessageDialog(null,"INVALID ENTRY");
                        return;
                    }
                    String transportation=c3.getSelectedItem()+"-"+c4.getSelectedItem();
                    ResultSet rs=c.s.executeQuery("select * from transport");
                    while(rs.next())
                    {
                        if(rs.getString(1).equals(transportation))
                        {
                            JOptionPane.showMessageDialog(null,"ALREADY PRESENT");
                            return;
                        }
                    }
                    c.s.executeUpdate("insert into transport values('" + transportation+"','"+t2.getText()+"')");
                    JOptionPane.showMessageDialog(null,"Saved Successfully");

                }
                catch (SQLException e1)
                {
                    throw new RuntimeException(e1);
                }
            }
        });
        b3.setBounds(720,230,100,25);
        p.add(b3);

        JButton b4=new JButton("CHANGE");
        b4.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e) {
                Conn c = new Conn();
                try
                {
                    String transportation2=c5.getSelectedItem()+"-"+c6.getSelectedItem();
                    if(c5.getSelectedItem().equals(c6.getSelectedItem()))
                    {
                        JOptionPane.showMessageDialog(null,"INVALID ENTRY");
                        return;
                    }
                    ResultSet rs=c.s.executeQuery("select * from transport");
                    while(rs.next())
                    {
                        if(rs.getString(1).equals(transportation2))
                        {
                            c.s.executeUpdate("update transport set price='"+t3.getText()+"' where distance='"+c5.getSelectedItem()+"-"+c6.getSelectedItem()+"'");
                            JOptionPane.showMessageDialog(null,"Changed Successfully");
                            return;
                        }
                    }
                    JOptionPane.showMessageDialog(null,"THIS ENTRY IS MISSING");
                } catch (SQLException e1) {
                    throw new RuntimeException(e1);
                }
            }
        });
        b4.setBounds(720,290,100,25);
        p.add(b4);

        JButton b5=new JButton("DELETE");
        b5.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e) {
                Conn c = new Conn();
                try
                {
                    String transportation3=c7.getSelectedItem()+"-"+c8.getSelectedItem();
                    if(c7.getSelectedItem().equals(c7.getSelectedItem()))
                    {
                        JOptionPane.showMessageDialog(null,"INVALID ENTRY");
                        return;
                    }
                    ResultSet rs=c.s.executeQuery("select * from transport");
                    while(rs.next())
                    {
                        if(rs.getString(1).equals(transportation3))
                        {
                            JOptionPane.showMessageDialog(null,"ALREADY PRESENT");
                            return;
                        }
                    }
                    c.s.executeUpdate("delete from transport where distance='"+c7.getSelectedItem()+"-"+c8.getSelectedItem()+"'");
                    JOptionPane.showMessageDialog(null,"Deleted Successfully");

                } catch (SQLException e1) {
                    throw new RuntimeException(e1);
                }
            }
        });
        b5.setBounds(575,350,100,25);
        p.add(b5);

        JButton b6=new JButton("BACK");
        b6.addActionListener(new ActionListener()
        {
            public void actionPerformed(ActionEvent e)
            {
                setVisible(false);
            }
        });
        b6.setBounds(400,420,100,25);
        p.add(b6);

    }
}

